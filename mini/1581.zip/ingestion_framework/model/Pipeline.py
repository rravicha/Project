class Pipeline:
    #PipelineMetadata Object
    metadata = None
    
    #Application Object
    application = None

    #Domain Object
    domain = None
    
    #List of Resource objects
    resources = None