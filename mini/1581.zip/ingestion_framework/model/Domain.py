class Domain:
    name = None
    id = None