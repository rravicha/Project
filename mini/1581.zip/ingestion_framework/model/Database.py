from ingestion_framework.model.ResourceType import ResourceType

class Database(ResourceType):
    database_type = None#Postgres/Sybase/Oracle/DB2/MySQL
    
    table_name = None
    filter = None
    query = None
    partition_columns = None #List of strings