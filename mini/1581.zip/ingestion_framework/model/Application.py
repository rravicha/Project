class Application:
    name = None
    id = None
    description = None