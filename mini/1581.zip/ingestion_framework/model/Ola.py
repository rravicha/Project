class Ola:
    start_time = None
    end_time = None