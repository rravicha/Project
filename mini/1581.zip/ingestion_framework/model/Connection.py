class Connection:
    environment_name = None
    secret_manager_key_name = None
    bucket_name = None