class FileFormat:
    file_format = None#xml/csv/excel/parquet...

class XML(FileFormat):
    root_tag = None
    row_tag = None

class CSV(FileFormat):
    has_header = None
    row_delimiter = None
    column_delimiter = None
    escape_character = None
    quote_character = None

class Excel(FileFormat):
    sheet_name = None