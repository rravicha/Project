from ingestion_framework.model.ResourceType import ResourceType

class Kafka(ResourceType):
    topic_name = None
    auto_offset_reset = None
    enable_auto_commit = None
    group_id = None
    consumer_timeout_ms = None
    value_serializer = None
    value_deserializer = None