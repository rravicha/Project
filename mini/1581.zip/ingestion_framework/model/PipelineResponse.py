class PipelineResponse:
    id = None
    jobstatus =  None
    error_message = None
    business_start_datetime = None
    business_end_datetime = None