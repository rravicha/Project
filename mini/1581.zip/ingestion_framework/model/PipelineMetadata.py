class PipelineMetadata:
    id = None
    version = None
    description = None
    phase = None #develop/published
    status = None #active/inactive
    
    load_type = None
    load_frequency = None
    load_phase = None
    
    sla = None
    #OLA object
    ola = None
    
    primary_key_list = None #List of strings
    cdc_timestamp_key_list = None #List of strings
    change_indicator_key_list = None #List of strings
    
    created_by = None
    created_timestamp = None
    modified_by = None
    modified_timestamp = None