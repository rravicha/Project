from ingestion_framework.model.ResourceType import ResourceType

class File(ResourceType):
    file_path = None
    file_name = None
    partition_columns = None #List of strings
    
    file_server_type = None#s3, FTP, HDFS...
    
    #FileFormat object
    file_format_metadata = None#csv, xml, excel...