class PipelineColumn:
    sequence_number = None

    name = None
    datatype = None
    length = None
    precision = None
    datetime_format = None
    
    transformation_logic = None