class Resource:
    flag = None#Source/Target
    
    #List of Connection objects
    connections = None
    
    #ResourceType Object
    metadata = None
    
    #List of PipelineColumn objects
    columns = None