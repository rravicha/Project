from enum import Enum,unique

@unique
class DynamodbEnum(Enum):
    JOB_STATUS_TABLE='datamesh-jobstatus-{}'
    INV_TABLE ='datamesh-inventory-pipeline-{}'
    COL_TABLE = 'datamesh-inventory-pipeline-col-{}'
    DQ_SUGGESTION_TABLE = 'datamesh-deequ-suggestion-{}'
    DQ_TRACKER_TABLE = 'datamesh-deequ-tracker-{}'
    TABLE_ITEMS = 'Items'
    LAST_EVALUATED_KEY = 'LastEvaluatedKey'
    DYNAMO_DB='dynamodb'
    LINEAGE_TRACKER_TABLE = 'datamesh-lineage-tracker-{}'
    #DynamoDB Pipeline Table
    APP_NAME = 'app_name'
    PIPELINE_ID = 'pipeline_id'
    VERSION_NUMBER = 'version_number'
    FREQUENCY_TYPE = 'frequency_type' 
    TARGET_FILE_NAME = 'target_file_name'
    #DynamoDB Pipeline Column Table
    PIPELINE_COLUMNS = 'pipeline_columns'
    SEQUENCE_NUMBER = 'sequence_number'
    SOURCE_COLUMN_NAME = 'source_column_name'
    TARGET_COLUMN_NAME = 'target_column_name'
    TARGET_DATATYPE = 'target_datatype'
    TARGET_LENGTH = 'target_length'
    TARGET_PRECISION = 'target_precision'
    #Yaml constants
    PIPELINES = 'pipelines'
    #DynamoDB JobStatus Table
    TABLE_NAME = 'table_name'
    EXECUTION_ID= 'execution_id'
    EXECUTION_START_DTTM='execution_start_dttm'
    EXECUTION_END_DTTM='execution_end_dttm'
    BUSINESS_ORDER_FROM_DTTM='business_order_from_dttm'
    BUSINESS_ORDER_TO_DTTM='business_order_to_dttm'
    LOAD_TYPE = 'load_type'
    LOAD_PHASE = 'load_phase'
    FINAL_COUNT = 'final_count'
    LANDING_COUNT = 'landing_count'
    PROCESSED_COUNT = 'processed_count'
    ERROR_MESSAGE = 'error_message'
    JOB_STATUS = 'job_status'
    SLA_MET = 'sla_met'
    #DynamoDB Response Object
    RESPONSE_METADATA = 'ResponseMetadata'
    HTTP_STATUS_CODE = 'HTTPStatusCode'

