from enum import Enum,unique

@unique
class JobParameters(Enum):
    APP_NAME = 'AppName'
    AWS_REGION = 'AWSRegion'
    JOB_ENVIRONMENT = 'JobEnvironment'
    OVERWRITE_MODE = 'overwrite'
    ACCOUNT = 'Account'
    DEFAULT = 'default'
    ENCODER = 'Encoder'
    YAML = 'yaml'
    S3 = 's3'
    ATHENA = 'athena'
    STS = 'sts'
    US_EAST_1='us-east-1'
    US_WEST_2='us-west-2'
    SUCCESS_FLAG = 'SUCCESS'
    FAILURE_FLAG = 'FAILURE'
    COLLIBRA_TOKEN='CollibraToken'
    JOB_MONITORING_URL='JobMonitoringURL'
    COLLIBRA_URL = 'CollibraURL'
