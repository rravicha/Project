from ingestion_framework.model.Domain import Domain


class DomainMapper:
    def __init__(self, logger):
        self.logger = logger

    
    def map_domain(self, domain_info):
        domain = Domain()
        domain.id = domain_info["id"]
        domain.name = domain_info["name"].lower()
        
        return domain