from ingestion_framework.model.Application import Application


class ApplicationMapper:
    def __init__(self, logger):
        self.logger = logger


    def map_application(self, application_info):
        application = Application()
        application.id = application_info["id"]
        application.name = application_info["name"].lower()
        application.description = application_info["description"]
        
        return application