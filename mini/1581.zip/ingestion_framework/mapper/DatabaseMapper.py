from ingestion_framework.model.Database import Database


class DatabaseMapper:
    def __init__(self, logger):
        self.logger = logger

    
    def map_database(self, database_info):
        database = Database()
        
        database.resource_type = "database"
        database.database_type = database_info["type"]
        database.table_name = database_info["tableName"]
        database.filter = database_info["filter"]
        database.query = database_info["query"]
        database.partition_columns = database_info["partitionColumns"]
        
        return database