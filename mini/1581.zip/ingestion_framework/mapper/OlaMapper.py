from ingestion_framework.model.Ola import Ola

class OlaMapper:
    def __init__(self, logger):
        self.logger = logger


    def map_ola(self, ola_info):
        ola = Ola()
        ola.start_time = ola_info["startTime"]
        ola.end_time = ola_info["endTime"]

        return ola