from ingestion_framework.enums.DynamodbEnum import DynamodbEnum
from ingestion_framework.model.PipelineResponse import PipelineResponse


class PipelineResponseMapper:
    def __init__(self, logger):
        self.logger = logger


    def map_jobstatus_result_to_pipeline_response(self, jobstatus_result):
        pipeline_response = PipelineResponse()
        
        pipeline_response.id = jobstatus_result[DynamodbEnum.PIPELINE_ID.value]
        pipeline_response.jobstatus = jobstatus_result[DynamodbEnum.JOB_STATUS.value]
        pipeline_response.error_message = jobstatus_result[DynamodbEnum.ERROR_MESSAGE.value]
        pipeline_response.business_start_datetime = jobstatus_result[DynamodbEnum.EXECUTION_END_DTTM.value]
        pipeline_response.business_end_datetime = jobstatus_result[DynamodbEnum.BUSINESS_ORDER_TO_DTTM.value]
        
        return pipeline_response