from ingestion_framework.model.Pipeline import Pipeline

from ingestion_framework.mapper.PipelineMetadataMapper import PipelineMetadataMapper
from ingestion_framework.mapper.ApplicationMapper import ApplicationMapper
from ingestion_framework.mapper.DomainMapper import DomainMapper
from ingestion_framework.mapper.ResourceMapper import ResourceMapper


class PipelineMapper:
    def __init__(self, logger):
        self.logger = logger

    
    def map_pipeline(self, pipeline_info):
        pipeline = Pipeline()
        
        pipeline.metadata = PipelineMetadataMapper(self.logger).map_pipeline_metadata(pipeline_info)

        pipeline.application = ApplicationMapper(self.logger).map_application(pipeline_info["appInfo"])
 
        pipeline.domain = DomainMapper(self.logger).map_domain(pipeline_info["domainInfo"])

        pipeline.resources = ResourceMapper(self.logger).map_all_resources(pipeline_info["resources"])
        
        self.print_pipeline(pipeline)

        return pipeline
    
    
    def print_pipeline(self, pipeline):
        self.logger.info(f"pipeline_id     {pipeline.metadata.id}")
        self.logger.info(f"pipeline_version     {pipeline.metadata.version}")
        self.logger.info(f"pipeline_description     {pipeline.metadata.description}")
        self.logger.info(f"pipeline_phase     {pipeline.metadata.phase}")
        self.logger.info(f"pipeline_status     {pipeline.metadata.status}")
        
        self.logger.info(f"primary_key_list     {pipeline.metadata.primary_key_list}")
        self.logger.info(f"cdc_timestamp_key_list     {pipeline.metadata.cdc_timestamp_key_list}")
        self.logger.info(f"change_indicator_key_list     {pipeline.metadata.change_indicator_key_list}")
        
        self.logger.info(f"load_type     {pipeline.metadata.load_type}")
        self.logger.info(f"load_frequency     {pipeline.metadata.load_frequency}")
        
        self.logger.info(f"sla     {pipeline.metadata.sla}")
        self.logger.info(f"ola start_time     {pipeline.metadata.ola.start_time}")
        self.logger.info(f"ola end_time     {pipeline.metadata.ola.end_time}")
        
        self.logger.info(f"created_by     {pipeline.metadata.created_by}")
        self.logger.info(f"created_timestamp     {pipeline.metadata.created_timestamp}")
        self.logger.info(f"modified_by     {pipeline.metadata.modified_by}")
        self.logger.info(f"modified_timestamp     {pipeline.metadata.modified_timestamp}")

        self.logger.info(f"app_name     {pipeline.application.name}")
        self.logger.info(f"app_id     {pipeline.application.id}")
        self.logger.info(f"app_description     {pipeline.application.description}")
        
        self.logger.info(f"domain_id     {pipeline.domain.id}")
        self.logger.info(f"domain_name     {pipeline.domain.name}")
        
        for resource in pipeline.resources:
            self.logger.info(f"resource_flag    {resource.flag}")
            
            self.logger.info(f"connections:")
            
            self.logger.info(f"dev:")
            connection = resource.connections["dev"]
            self.logger.info(f"environment_name    {connection.environment_name}")
            self.logger.info(f"database_secret_manager_name    {connection.secret_manager_key_name}")
            self.logger.info(f"bucket_name    {connection.bucket_name}")
            
            self.logger.info(f"qa:")
            connection = resource.connections["qa"]
            self.logger.info(f"environment_name    {connection.environment_name}")
            self.logger.info(f"database_secret_manager_name    {connection.secret_manager_key_name}")
            self.logger.info(f"bucket_name    {connection.bucket_name}")
            
            self.logger.info(f"uat:")
            connection = resource.connections["uat"]
            self.logger.info(f"environment_name    {connection.environment_name}")
            self.logger.info(f"database_secret_manager_name    {connection.secret_manager_key_name}")
            self.logger.info(f"bucket_name    {connection.bucket_name}")
            
            self.logger.info(f"prd:")
            connection = resource.connections["prd"]
            self.logger.info(f"environment_name    {connection.environment_name}")
            self.logger.info(f"database_secret_manager_name    {connection.secret_manager_key_name}")
            self.logger.info(f"bucket_name    {connection.bucket_name}")
            
            self.logger.info(f"columns:")
            
            for column in resource.columns:
                self.logger.info(f"sequence_number    {column.sequence_number}")
                self.logger.info(f"column_name    {column.name}")
                self.logger.info(f"column_datatype    {column.datatype}")
                self.logger.info(f"column_length    {column.length}")
                self.logger.info(f"column_precision    {column.precision}")
                self.logger.info(f"column_datetime_format    {column.datetime_format}")
                self.logger.info(f"transformation_logic    {column.transformation_logic}")
            
            self.logger.info(f"resource_type    {resource.metadata.resource_type}")
            
            if resource.metadata.resource_type == "database":
                self.logger.info(f"database_type    {resource.metadata.database_type}")
                self.logger.info(f"table_name    {resource.metadata.table_name}")
                self.logger.info(f"filter    {resource.metadata.filter}")
                self.logger.info(f"query    {resource.metadata.query}")
                self.logger.info(f"partition_columns    {resource.metadata.partition_columns}")
            elif resource.metadata.resource_type == "kafka":
                self.logger.info(f"topic_name    {resource.metadata.topic_name}")
                self.logger.info(f"auto_offset_reset    {resource.metadata.auto_offset_reset}")
                self.logger.info(f"enable_auto_commit    {resource.metadata.enable_auto_commit}")
                self.logger.info(f"group_id    {resource.metadata.group_id}")
                self.logger.info(f"consumer_timeout_ms    {resource.metadata.consumer_timeout_ms}")
                self.logger.info(f"value_serializer    {resource.metadata.value_serializer}")
                self.logger.info(f"value_deserializer    {resource.metadata.value_deserializer}")
            elif resource.metadata.resource_type == "file":
                self.logger.info(f"file_path    {resource.metadata.file_path}")
                self.logger.info(f"file_name    {resource.metadata.file_name}")
                self.logger.info(f"partition_columns    {resource.metadata.partition_columns}")
                self.logger.info(f"file_server_type    {resource.metadata.file_server_type}")
                self.logger.info(f"file_format    {resource.metadata.file_format_metadata.file_format}")
                
                if resource.metadata.file_format_metadata.file_format == "xml":
                    self.logger.info(f"root_tag    {resource.metadata.file_format_metadata.root_tag}")
                    self.logger.info(f"row_tag    {resource.metadata.file_format_metadata.row_tag}")
                elif resource.metadata.file_format_metadata.file_format == "csv":
                    self.logger.info(f"has_header    {resource.metadata.file_format_metadata.has_header}")
                    self.logger.info(f"row_delimiter    {resource.metadata.file_format_metadata.row_delimiter}")
                    self.logger.info(f"column_delimiter    {resource.metadata.file_format_metadata.column_delimiter}")
                    self.logger.info(f"escape_character    {resource.metadata.file_format_metadata.escape_character}")
                    self.logger.info(f"quote_character    {resource.metadata.file_format_metadata.quote_character}")
                elif resource.metadata.file_format_metadata.file_format == "excel":
                    self.logger.info(f"sheet_name    {resource.metadata.file_format_metadata.sheet_name}")