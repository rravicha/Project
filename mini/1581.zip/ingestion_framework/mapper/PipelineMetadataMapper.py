from ingestion_framework.model.PipelineMetadata import PipelineMetadata
from ingestion_framework.mapper.OlaMapper import OlaMapper

class PipelineMetadataMapper:
    def __init__(self, logger):
        self.logger = logger

    def map_pipeline_metadata(self, pipeline_info):
        metadata = PipelineMetadata()
        
        metadata.id = pipeline_info["id"]
        metadata.version = pipeline_info["versionNumber"]
        metadata.description = pipeline_info["description"]
        
        metadata.phase = pipeline_info["phase"].lower()
        metadata.status = pipeline_info["status"].lower()
        
        metadata.load_type = pipeline_info["loadType"].lower()
        metadata.load_frequency = pipeline_info["loadFrequency"].lower()
        metadata.load_phase = 'raw'

        metadata.primary_key_list = pipeline_info["primaryCompositeKey"]
        metadata.cdc_timestamp_key_list = pipeline_info["cdcTimestampKey"]
        metadata.change_indicator_key_list = pipeline_info["changeIndicatorKey"]
        
        metadata.sla = pipeline_info["sla"]
        
        metadata.ola = OlaMapper(self.logger).map_ola(pipeline_info["ola"])
        
        metadata.created_by = pipeline_info["createdBy"]
        metadata.created_timestamp = pipeline_info["createdDate"]
        metadata.modified_by = pipeline_info["modifiedBy"]
        metadata.modified_timestamp = pipeline_info["modifiedDate"]
        
        return metadata