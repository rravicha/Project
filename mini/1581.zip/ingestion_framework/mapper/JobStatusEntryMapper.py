from datetime import datetime
from ingestion_framework.enums.DynamodbEnum import DynamodbEnum


class JobStatusEntryMapper:
    def __init__(self, logger):
        self.logger = logger
        
    def generate_initial_entry(self, pipeline, job_start_datetime, job_env):
        jobstatus_entry = {}
        
        jobstatus_entry[DynamodbEnum.PIPELINE_ID.value] = pipeline.metadata.id
        jobstatus_entry[DynamodbEnum.EXECUTION_ID.value] = str(datetime.now().timestamp()).replace(".", "")

        jobstatus_entry[DynamodbEnum.EXECUTION_END_DTTM.value] = 'None'
        jobstatus_entry[DynamodbEnum.BUSINESS_ORDER_TO_DTTM.value] = 'None'
        jobstatus_entry[DynamodbEnum.EXECUTION_START_DTTM.value] = str(job_start_datetime.strftime("%Y-%m-%d %H:%M:%S"))
        jobstatus_entry[DynamodbEnum.EXECUTION_END_DTTM.value] = 'None'
        
        jobstatus_entry[DynamodbEnum.LOAD_TYPE.value] = pipeline.metadata.load_type
        jobstatus_entry[DynamodbEnum.LOAD_PHASE.value] = pipeline.metadata.load_phase
        jobstatus_entry[DynamodbEnum.FREQUENCY_TYPE.value] = pipeline.metadata.load_frequency
        
        jobstatus_entry[DynamodbEnum.JOB_STATUS.value] = 'STARTED'
        
        jobstatus_entry[DynamodbEnum.LANDING_COUNT.value] = 0
        jobstatus_entry[DynamodbEnum.FINAL_COUNT.value] = 0
        jobstatus_entry[DynamodbEnum.PROCESSED_COUNT.value] = 0

        jobstatus_entry[DynamodbEnum.TABLE_NAME.value] = self.construct_target_table_name(pipeline, job_env)
        jobstatus_entry[DynamodbEnum.SLA_MET.value] = 'None'
        jobstatus_entry[DynamodbEnum.ERROR_MESSAGE.value] = 'None'
        
        return jobstatus_entry
    
    
    def update_jobstatus_entry(self, jobstatus_entry, business_start_datetime, business_end_datetime, job_end_datetime, jobstatus_flag, landing_count, final_count, processed_count, sla_met, error_message):
        jobstatus_entry[DynamodbEnum.EXECUTION_END_DTTM.value] = business_start_datetime
        jobstatus_entry[DynamodbEnum.BUSINESS_ORDER_TO_DTTM.value] = business_end_datetime

        jobstatus_entry[DynamodbEnum.EXECUTION_END_DTTM.value] = job_end_datetime
        
        jobstatus_entry[DynamodbEnum.JOB_STATUS.value] = jobstatus_flag
        
        jobstatus_entry[DynamodbEnum.LANDING_COUNT.value] = landing_count
        jobstatus_entry[DynamodbEnum.FINAL_COUNT.value] = final_count
        jobstatus_entry[DynamodbEnum.PROCESSED_COUNT.value] = processed_count

        jobstatus_entry[DynamodbEnum.SLA_MET] = sla_met
        jobstatus_entry[DynamodbEnum.ERROR_MESSAGE.value] = error_message
        
        return jobstatus_entry
    
    
    def construct_target_table_name(self, pipeline, job_env):
        table_name = ""
        
        for resource in pipeline.resources:
            if resource.flag == "target":
                if resource.metadata.resource_type == "database":
                    table_name = resource.metadata.table_name
                elif resource.metadata.resource_type == "file":
                    domain_name = pipeline.domain.name
                    pipeline_phase = pipeline.metadata.load_phase
                    file_name = resource.metadata.file_name
                    table_name = f"datamesh_{domain_name}_{pipeline_phase}_{job_env}.{file_name}"
        
        return table_name