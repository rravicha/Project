from ingestion_framework.model.File import File
from ingestion_framework.model.FileFormat import FileFormat, XML, CSV, Excel


class FileMapper:
    def __init__(self, logger):
        self.logger = logger


    def map_file(self, file_info):
        file = File()
        
        file.resource_type = "file"
        file.file_path = file_info["path"]
        file.file_name = file_info["name"]
        file.partition_columns = file_info["partitionColumns"]
        file.file_server_type = file_info["serverType"].lower()
        
        file_format = file_info["format"].lower()
                
        if file_format == "xml":
            file.file_format_metadata = self.map_xml(file_format, file_info["xmlInfo"])
        elif file_format == "csv" or file_format == "pip":
            file.file_format_metadata = self.map_csv(file_format, file_info["csvInfo"])
        elif file_format == "excel":
            file.file_format_metadata = self.map_excel(file_format, file_info["excelInfo"])
        elif file_format == "parquet":
            file.file_format_metadata = self.map_parquet(file_format)
        else:
            self.logger.error("Given file format is not supported")
            raise Exception("Given file format is not supported")
        
        return file
    

    def map_xml(self, file_format, xml_info):
        xml = XML()
            
        xml.file_format = file_format
        xml.root_tag = xml_info["rootTag"]
        xml.row_tag = xml_info["rowTag"]
        
        return xml
    
    
    def map_csv(self, file_format, csv_info):
        csv = CSV()
            
        csv.file_format = file_format
        csv.has_header = csv_info["hasHeader"]
        csv.row_delimiter = csv_info["rowDelimiter"]
        csv.column_delimiter = csv_info["columnDelimiter"]
        csv.escape_character = csv_info["escapeCharacter"]
        csv.quote_character = csv_info["quoteCharacter"]
        
        return csv
    
    
    def map_excel(self, file_format, excel_info):
        excel = Excel()
            
        excel.file_format = file_format
        excel.sheet_name = excel_info["sheetName"]
        
        return excel
    
    
    def map_parquet(self, file_format):
        file_format_metadata = FileFormat()
        
        file_format_metadata.file_format = file_format
        
        return file_format_metadata