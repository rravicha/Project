from ingestion_framework.model.Connection import Connection


class ConnectionMapper:
    def __init__(self, logger):
        self.logger = logger


    def map_all_connections(self, connections_info):
        connections = {}
        for connection_info in connections_info:
            connection = self.map_connection(connection_info)
            connections[connection.environment_name] = connection

        return connections
    

    def map_connection(self, connection_info):
        connection = Connection()
                
        connection.environment_name = connection_info["environment"].lower()
        if "secretManagerName" in connection_info:
            connection.secret_manager_key_name = connection_info["secretManagerName"].lower()
        else:
            connection.secret_manager_key_name = None
                
        if "bucketName" in connection_info:
            connection.bucket_name = connection_info["bucketName"].lower()
        else:
            connection.bucket_name = None
        
        return connection