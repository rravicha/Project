from ingestion_framework.model.Resource import Resource

from ingestion_framework.mapper.ConnectionMapper import ConnectionMapper
from ingestion_framework.mapper.PipelineColumnMapper import PipelineColumnMapper
from ingestion_framework.mapper.DatabaseMapper import DatabaseMapper
from ingestion_framework.mapper.KafkaMapper import KafkaMapper
from ingestion_framework.mapper.FileMapper import FileMapper

class ResourceMapper:
    def __init__(self, logger):
        self.logger = logger


    def map_all_resources(self, resources_info):
        resources = []
        for resource_info in resources_info:
            resources.append(self.map_resource(resource_info))

        return resources

    
    def map_resource(self, resource_info):
        resource = Resource()
        
        resource.flag = resource_info["type"].lower()
            
        resource.connections = ConnectionMapper(self.logger).map_all_connections(resource_info["connections"])
            
        resource.columns = PipelineColumnMapper(self.logger).map_all_pipeline_columns(resource_info["columnsInfo"])
            
        if "databaseInfo" in resource_info:
            resource.metadata = DatabaseMapper(self.logger).map_database(resource_info["databaseInfo"])
        elif "kafkaInfo" in resource_info:
            resource.metadata = KafkaMapper(self.logger).map_kafka(resource_info["kafkaInfo"])
        elif "fileInfo" in resource_info:
            resource.metadata = FileMapper(self.logger).map_file(resource_info["fileInfo"])
        else:
            self.logger.error("Given resource information is not supported")
            raise Exception("Given resource information is not supported")
        
        return resource