from ingestion_framework.model.PipelineColumn import PipelineColumn


class PipelineColumnMapper:
    def __init__(self, logger):
        self.logger = logger


    def map_all_pipeline_columns(self, columns_info):
        columns = []
        for column_info in columns_info:
            columns.append(self.map_pipeline_column(column_info))

        return columns


    def map_pipeline_column(self, column_info):
        column = PipelineColumn()
                
        column.sequence_number = column_info["sequenceNumber"]
        if "transformationLogic" in column_info:
            column.transformation_logic = column_info["transformationLogic"]
        else:
            column.transformation_logic = None
        column.name = column_info["name"]
        column.datatype = column_info["datatype"]
        column.length = column_info["length"]
        column.precision = column_info["precision"]
        column.datetime_format = column_info["dateTimeFormat"]
        
        return column