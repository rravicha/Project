from ingestion_framework.model.Kafka import Kafka


class KafkaMapper:
    def __init__(self, logger):
        self.logger = logger


    def map_kafka(self, kafka_info):
        kafka = Kafka()
        
        kafka.resource_type = "kafka"
        kafka.topic_name = kafka_info["topicName"]
        kafka.auto_offset_reset = kafka_info["autoOffsetReset"]
        kafka.enable_auto_commit = kafka_info["enableAutoCommit"]
        kafka.group_id = kafka_info["groupId"]
        kafka.consumer_timeout_ms = kafka_info["consumerTimeoutMs"]
        kafka.value_serializer = kafka_info["valueDeserializer"]
        kafka.value_deserializer = kafka_info["valueSerializer"]
        
        return kafka