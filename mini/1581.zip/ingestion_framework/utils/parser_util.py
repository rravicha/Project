import yaml, boto3, json
import numpy as np
from collections import defaultdict
import pyspark.sql.functions as F

from ingestion_framework.scripts import job_initializer
from ingestion_framework.enums.JobParameters import JobParameters
from ingestion_framework.enums.DynamodbEnum import DynamodbEnum

# Module Constants
SCRIPT_NAME = "datamesh_parser"

def load_parser_util(job_env, aws_region):
    ''' Function reads the inventory table and creates app specific Yaml files '''
    function_name = 'load_parser_util'

    print(f'{SCRIPT_NAME} - {function_name} - processing to create the yaml file  has  started')
    sts_client      = boto3.client(JobParameters.STS.value)
    aws_account_id  = sts_client.get_caller_identity()[JobParameters.ACCOUNT.value]
    
    # Initilize spark
    spark = job_initializer.initializeSpark(JobParameters.PARSER)
    
    # Connect to dynamoDB
    print(f'{SCRIPT_NAME} - {function_name} - Connection to dynamo db  started')
    dynamodb = boto3.resource(DynamodbEnum.DYNAMO_DB.value, region_name=JobParameters.US_EAST_1.value)
    print(f'{SCRIPT_NAME} - Connection to dynamo db established :{dynamodb}')
    
    try:
        print(f'{SCRIPT_NAME} - Reading the Inventory Table in  :{dynamodb}  in environement {job_env}  started')
        inventory_table       = dynamodb.Table(DynamodbEnum.INV_TABLE.format(job_env))
        inventory_table_scan  = inventory_table.scan()
        inventory_table_items = inventory_table_scan[DynamodbEnum.TABLE_ITEMS.value]
        while DynamodbEnum.LAST_EVALUATED_KEY.value in inventory_table_scan:
            inventory_table_scan = inventory_table.scan(ExclusiveStartKey=inventory_table_scan[DynamodbEnum.LAST_EVALUATED_KEY.value])
            inventory_table_items.extend(inventory_table_scan[DynamodbEnum.TABLE_ITEMS.value])
        print(f'{SCRIPT_NAME} - Successfully read the Inventory Table {inventory_table} in  :{dynamodb}  in environement {job_env}  finished')

        print(f'{SCRIPT_NAME} - Reading -  cols_table in {dynamodb} to extract columns started ')
        cols_table       = dynamodb.Table(DynamodbEnum.COL_TABLE.value.format(job_env))
        cols_table_scan  = cols_table.scan()
        cols_table_items = cols_table_scan[DynamodbEnum.TABLE_ITEMS.value]
        while DynamodbEnum.LAST_EVALUATED_KEY.value in cols_table_scan:
            cols_table_scan = cols_table.scan(ExclusiveStartKey=cols_table_scan[DynamodbEnum.LAST_EVALUATED_KEY.value])
            cols_table_items.extend(cols_table_scan[DynamodbEnum.TABLE_ITEMS.value])
        print(f'{SCRIPT_NAME} - Successfully read the Columns Table -  :{cols_table} in {dynamodb} to extract columns finished ')

        # create encoder to account for non json serializable objects
        EncoderMethod = lambda self, obj: str(obj)
        EncoderMap    = {JobParameters.DEFAULT.value: EncoderMethod}
        Encoder       = type(JobParameters.ENCODER.value, (json.JSONEncoder,), EncoderMap)

        # generate json string of inventory table items and convert to Spark Dataframe
        print(f'{SCRIPT_NAME} - Conversion of inventory_records_json into a spark dataframe started')
        inventory_records_json = json.dumps(inventory_table_items, cls=Encoder)
        inventory_records_df   = spark.read.json(spark.sparkContext.parallelize([inventory_records_json]))
        print(f'{SCRIPT_NAME} - Conversion of inventory_records_json into a spark dataframe finished')

        print(f'{SCRIPT_NAME} - Conversion of col_records_json into a spark dataframe started')
        col_records_json = json.dumps(cols_table_items, cls=Encoder)
        col_records_df   = spark.read.json(spark.sparkContext.parallelize([col_records_json]))
        print(f'{SCRIPT_NAME} - Conversion of col_records_json into a spark dataframe finished')

        print(f'{SCRIPT_NAME} - Transforming col_records_df by grouping and aggregation max version number in dynamo for pipeline cols and create a new spark dataframe started')
        
        col_recs_grp_df = col_records_df.groupBy(DynamodbEnum.PIPELINE_ID.value, DynamodbEnum.VERSION_NUMBER.value) \
        .agg(F.collect_list(F.to_json(
        F.struct(DynamodbEnum.SEQUENCE_NUMBER.value, DynamodbEnum.SOURCE_COLUMN_NAME.value, DynamodbEnum.SOURCE_DATATYPE, \
                 DynamodbEnum.SOURCE_LENGTH, DynamodbEnum.SOURCE_PRECISION, DynamodbEnum.SOURCE_DATETIME_FORMAT, \
                 DynamodbEnum.TARGET_COLUMN_NAME.value, DynamodbEnum.TARGET_DATATYPE.value, DynamodbEnum.TARGET_LENGTH.value, \
                 DynamodbEnum.TARGET_PRECISION.value, DynamodbEnum.TARGET_DATETIME_FORMAT, DynamodbEnum.TRANSFORMATION_LOGIC))) \
             .alias(DynamodbEnum.PIPELINE_COLUMNS.value))
        col_recs_grp_df = col_recs_grp_df.withColumnRenamed(DynamodbEnum.PIPELINE_ID.value, 'p_id')   \
            .withColumnRenamed(DynamodbEnum.VERSION_NUMBER.value, 'v_no') \
                .select('p_id', 'v_no', F.concat(F.lit('['), F.concat_ws(',', DynamodbEnum.PIPELINE_COLUMNS.value), F.lit(']')).alias( DynamodbEnum.PIPELINE_COLUMNS.value))

        print(f'{SCRIPT_NAME} - Transforming col_records_df by grouping and aggregation to get max version number in dynamo for pipeline cols and create a new spark dataframe  finished')   
        
        
        # ensure that array/struct types have proper json format
        for column in inventory_records_df.dtypes:
            column_name  = column[0]
        column_data_type = column[1]
        if column_data_type != 'string':
            inventory_records_df = inventory_records_df.withColumn(column_name, F.to_json(column_name))
        
        print(f'{SCRIPT_NAME}- Converting spark dataframe inventory_records into a pandas dataframe started ')
        inventory_records_df = inventory_records_df.join(col_recs_grp_df,
                (inventory_records_df.pipeline_id    == col_recs_grp_df.p_id) &
                (inventory_records_df.version_number == col_recs_grp_df.v_no),
                'inner').drop('p_id', 'v_no')

        inventory_records_df = inventory_records_df.toPandas()
        print(f'{SCRIPT_NAME}- Converting spark dataframe inventory_records into a pandas dataframe finished ')

        # construct the dictionary with all apps
        print(f'{SCRIPT_NAME} - Constructing a dictionary with all apps started')
        columns        = inventory_records_df.columns
        app_name_index = columns.get_loc(DynamodbEnum.APP_NAME.value)
        app_groups     = defaultdict(lambda: [])

        for record in inventory_records_df.values:
            app_name = record[app_name_index]
            pipeline = np.delete(record, app_name_index)
            app_groups[app_name].append(pipeline)
        print(f'{SCRIPT_NAME} - Constructing a dictionary with all apps finished')

        # loop through each app and create app specific yaml files
        s3_client = boto3.client(JobParameters.S3.value)
        cols = list(columns.drop(DynamodbEnum.APP_NAME.value))
        for app_name, pipeline_data in app_groups.items():
            pipelines = [dict(zip(cols, data)) for data in pipeline_data]
            app_level_dictionary = {DynamodbEnum.APP_NAME.value: app_name, DynamodbEnum.PIPELINES.value: pipelines}
            datamesh_bucket_name = f"datamesh-ingfw-{aws_account_id}-{job_env}-{aws_region}"
            print(f'{SCRIPT_NAME} - {function_name} - processing to create the yaml file(s)  has  started')
            s3_client.put_object(Bucket=f"{datamesh_bucket_name}",Key=f"{JobParameters.DEFAULT.value_S3_YAML}{app_name}.{JobParameters.YAML.value}",
                Body=yaml.dump(app_level_dictionary))
        print(f'{SCRIPT_NAME} - {function_name} - processing to create the yaml file  has  completed')

    except Exception as err:
        print(f'{SCRIPT_NAME} - {function_name} -  Failed with error: {err}')
        raise Exception(f'{SCRIPT_NAME}  - Failed with error: {err}') from err
