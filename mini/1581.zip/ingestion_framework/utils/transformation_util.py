import numpy as np
import json, traceback, types, pyspark
import pyspark.sql.functions as F
import pyspark.sql.types as T
from datetime import datetime
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.window import Window

from ingestion_framework.utils import  athena_util
from ingestion_framework.utils.lineage_tracker_util import insert_dynamo_record
from ingestion_framework.services.LoggerService import LoggerService
logger = LoggerService.get_root_logger()

class TranformationUtil:
    def __init__(self, logger, spark, source_target_mapping, job_name, job_environment, domain_name):
        self.logger = logger
        self.spark = spark
        self.source_target_mapping = source_target_mapping
        self.job_name = job_name
        self.job_environment = job_environment
        self.domain_name = domain_name

    # Add a column of data to the table in columnData with the name columnName

    def addColumn(self, data, columnName, columnData, dataType):
        """ add column of desired data type """
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Adding column to data")
        if not isinstance(data, DataFrame):
            raise TypeError('data is not a dataframe')

        if not isinstance(columnName, str):
            raise TypeError('columnName is not a str')

        if not isinstance(columnData, list):
            raise TypeError('columnData is not a proper list')

        if not isinstance(columnData[0], list):
            columnData = [[i] for i in columnData]

        try:
            if isinstance(dataType, T.DataType):
                schema = data.schema
                schema = schema.add(columnName, dataType)
            elif isinstance(dataType, str):
                schemaJson = json.loads(data.schema.json())
                columnTypes = schemaJson['fields']
                columnTypes = columnTypes.append({'metadata': {}, 'name': columnName, 'type': dataType})
                schema = T.StructType.fromJson(schemaJson)

            datalist = data.rdd.collect()
            new_list = [list(datalist[i]) + columnData[i] for i in range(0, len(columnData))]
            new_data = self.spark.createDataFrame(data=new_list, schema=schema.add(columnName, dataType))
            insert_dynamo_record(self.job_name, "addColumn", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"added_col": [columnName], "final_df_cols": [str(col) for col in new_data.dtypes],
                                  "target_tables": id(new_data)})
            self.logger.info(f'Finished')
            return new_data
        except Exception:
            self.logger.error('Error while adding ' + columnName)
            traceback.print_exc()
            raise Exception

    # Add a field with a fixed value.

    def addField(self, data, columnName, value, index=None):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Adding field to data")
        if not isinstance(data, DataFrame):
            raise TypeError('data is not a dataframe')

        if not isinstance(columnName, str):
            raise TypeError('columnName is not a str')

        try:
            new_data = data.withColumn(columnName, F.lit(value))
            insert_dynamo_record(self.job_name, "addField", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"added_col": [columnName], "final_df_cols": [str(col) for col in new_data.dtypes],
                                  "source_tables": [id(data)],
                                  "target_tables": id(new_data)})
            self.logger.info(f'Finished')
            return new_data
        except Exception:
            self.logger.error('Error while adding ' + columnName)
            traceback.print_exc()
            raise

    # Add a field with a value calculated by a lambda function.

    def addComputedField(self, data, fieldName, computation, *involvedCols):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Adding computed field to data")

        if not isinstance(data, DataFrame):
            self.logger.error('data passed in is not list')
            raise TypeError()

        if not isinstance(fieldName, str):
            self.logger.error('fieldName passed in is not string')
            raise TypeError()

        if not isinstance(computation, types.LambdaType):
            self.logger.error('computation passed in is not lambda')
            raise TypeError()

        try:
            new_data = data.withColumn(fieldName, F.udf(computation)(*involvedCols))
            insert_dynamo_record(self.job_name, "addComputedField", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"added_col": [fieldName], "final_df_cols": [str(col) for col in new_data.dtypes],
                                  "source_tables": [id(data)],
                                  "target_tables": id(new_data)})
            self.logger.info(f'Finished')
            return new_data
        except Exception:
            self.logger.error('Error while attempting to add a computed field')
            traceback.print_exc()
            raise

    # Add multiple fields with fixed values.
    # Columns attribute is a list and each element in that list must include a column name and value.

    def addFields(self, data, columns):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Adding field to data")
        if not isinstance(data, DataFrame):
            raise TypeError('data is not a DataFrame')

        if not isinstance(columns, list):
            raise TypeError('columns is not a list')
        new_data = data
        try:
            for col in columns:
                name, value = col[0], col[1]
                new_data = new_data.withColumn(name, F.lit(value))
            insert_dynamo_record(self.job_name, "addFields", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"added_col": columns, "final_df_cols": [str(col) for col in new_data.dtypes],
                                  "source_tables": [id(data)],
                                  "target_tables": id(new_data)})
            self.logger.info(f'Finished')
            return new_data
        except Exception:
            self.logger.error('Error while adding ' + str(columns))
            traceback.print_exc()
            raise

    # create a new dataframe limited to chosen columns and in the order specified.
    # You can reorder existing columns or get a subset of existing columns

    def getColumns(self, data, *correctOrder):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Adding field to data")

        if not isinstance(data, DataFrame):
            raise TypeError('data is not a DataFrame')

        try:
            final_data = data.select(*correctOrder)
            insert_dynamo_record(self.job_name, "getColumns", self.job_environment, self.source_target_mapping,
                                 self.domain_name, {"source_tables": [id(data)], "selected_cols": list(*correctOrder),
                                                    "final_df_cols": [str(col) for col in final_data.dtypes],
                                                    "target_tables": id(final_data)})
            self.logger.info(f'Finished')
            return final_data
        except Exception:
            self.logger.error('Error in renaming columns')
            traceback.print_exc()
            raise

    # return source dataframe with columns re-ordered so that they are in the same order as that of the target dataframe

    def reorderColumnsToMatchTarget(self, source, target):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Reordering columns to match target data")
        insert_dynamo_record(self.job_name, "reorderColumnsToMatchTarget", self.job_environment,
                             self.source_target_mapping, self.domain_name,
                             {"source_tables": [id(source)], "selected_cols": list(*target.columns),
                              "final_df_cols": [str(col) for col in target.dtypes],
                              "target_tables": id(target)})
        self.logger.info(f'Finished')
        return source.select(*target.columns)

    # rename columns in data according to dictionary object passed in where they key is the original name and the value is the column's new name.

    def rename(self, src_data, columnsToChange):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Renaming columns")
        cols_before_rename = src_data.columns
        if not isinstance(src_data, DataFrame):
            raise TypeError('data is not a list')

        if not isinstance(columnsToChange, dict):
            raise TypeError('columnsToChange is not a dictionary')

        try:
            data = src_data
            for col, new_col in columnsToChange.items():
                data = data.withColumnRenamed(col, new_col)
            insert_dynamo_record(self.job_name, "rename", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"selected_cols": cols_before_rename, "renamed_cols": columnsToChange,
                                  "source_tables": [id(src_data)],
                                  "final_df_cols": [str(col) for col in data.dtypes], "target_tables": id(data)})
            self.logger.info( f'Finished')
            return data
        except Exception:
            self.logger.error('Error in renaming columns')
            traceback.print_exc()
            raise

    # drop columns in df according to how many rows are null.
    # 'any' : If any NA values are present, drop that column.
    # 'all' : If all values are NA, drop that column.

    def dropnacolumns(self, df, how='any'):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("dropping columns with " + how + " null rows")
        columnsToDrop = []
        numRows = df.count()
        cols_before_drop = df.columns
        if how.lower() == 'all':
            for col in df.columns:
                withoutnulls = df.select(col).dropna()
                if withoutnulls.count() == 0:  # all values in column were null
                    columnsToDrop.append(col)
        elif how.lower() == 'any':
            for col in df.columns:
                withoutnulls = df.select(col).dropna()
                if withoutnulls.count() < numRows:
                    columnsToDrop.append(col)
        else:
            raise ("invalid input for how")
        try:
            data = df.drop(*columnsToDrop)
            insert_dynamo_record(self.job_name, "dropnacolumns", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"source_tables": [id(df)], "selected_cols": cols_before_drop,
                                  "dropped_cols": columnsToDrop, "final_df_cols": [str(col) for col in data.dtypes],
                                  "target_tables": id(data)})
            self.logger.info(" Finished")
            return data
        except Exception:
            self.logger.error(" couldn't drop columns")
            traceback.print_exc()
            raise Exception

    # convert pandas DataFrame to pyspark DataFrame while retaining schema and column names.
    # Important: this conversion function will convert every column's data type to string
    # in the pyspark dataframe.
    # To retain your pandas Dataframe's data types either infer or create your desired schema explicitly.

    def pandasToSparkDF(self, pandas_df):
        self.logger.info(f'Transformation Util - pandasToSparkDF - Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Transformation Util - pandasToSparkDF - creating pyspark dataframe from pandas dataframe")
        schema = [T.StructField(col, T.StringType(), True) for col in pandas_df.columns.to_list()]
        if pandas_df.empty:
            return self.spark.createDataFrame([], T.StructType(schema))
        else:
            return self.spark.createDataFrame(pandas_df, T.StructType(schema)).replace('NaN', None)

    # returns True if dataframes passed in are equal and prints a message to log file
    # indicating what is currently happening in the process.

    def testDataFramesEqual(self, actual, expected, message):
        self.logger.info(f'Transformation Util - testDataFramesEqual - Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Transformation Util - testDataFramesEqual - test equality of two dataframes")
        try:
            actual_count = actual.count()
            expected_count = expected.count()
            if set(actual.columns) == set(expected.columns):
                if actual_count >= expected_count:
                    diff = actual.select(expected.columns).subtract(expected.select(expected.columns))
                else:
                    diff = expected.select(expected.columns).subtract(actual.select(expected.columns))
                if diff.count() == 0:
                    logger.debug(message)
                    return True
                else:
                    if set(actual.collect()) == set(expected.collect()):
                        logger.debug(message)
                        return True
                    else:
                        logger.debug("difference in rows")
                        return False
            else:
                self.logger.info("actual columns: " + str(actual.columns))
                self.logger.info("expected columns: " + str(expected.columns))
                return False
        except Exception:
            actual.printSchema()
            expected.printSchema()
            traceback.print_exc()
            raise Exception

    # Perform an equi-join/inner join on the given tables.
    # Pass column keys in as list to keyColumns (if column names are the same)
    # or leftKeys and rightKeys (if column names are different).

    def join(self, leftSideData, rightSideData, keyColumns, leftKeys=None, rightKeys=None, leftPrefix=None,
             rightPrefix=None):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("join two dataframes")

        if not isinstance(leftSideData, DataFrame):
            raise TypeError('leftSideData passed in is not list')

        if not isinstance(rightSideData, DataFrame):
            raise TypeError('rightSideData passed in is not list')

        if not isinstance(keyColumns, list) and not isinstance(keyColumns, str):
            raise TypeError('keyColumns passed in is not list')

        try:
            if isinstance(leftKeys, list) and isinstance(rightKeys, list) and len(leftKeys) == len(rightKeys):
                rightcol = rightSideData.columns
                for col in rightKeys:
                    rightcol.remove(col)
                correctorder = leftSideData.columns + rightcol

                joincondition = []
                for idx in range(0, len(leftKeys)):
                    joincondition.append(leftSideData[leftKeys[idx]] == rightSideData[rightKeys[idx]])

                data = leftSideData.join(rightSideData, joincondition).select(correctorder)
            elif isinstance(leftKeys, str) and isinstance(rightKeys, str):
                correctorder = rightSideData.columns.remove(rightKeys)

                data = leftSideData.join(rightSideData, leftSideData[leftKeys] == rightSideData[rightKeys]).select(
                    correctorder)
            elif isinstance(keyColumns, list):
                rightcol = rightSideData.columns
                for col in keyColumns:
                    rightcol.remove(col)

                correctorder = leftSideData.columns + rightcol
                data = leftSideData.join(rightSideData, keyColumns).select(correctorder)
            elif isinstance(keyColumns, str):
                rightcol = rightSideData.columns
                rightcol.remove(keyColumns)
                correctorder = leftSideData + rightcol
                data = leftSideData.join(rightSideData, keyColumns).select(correctorder)
            else:
                self.logger.error("keyColumns not a recognized data type")
                raise TypeError("keyColumns not a recognized data type")
            insert_dynamo_record(self.job_name, "join", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"left_df_cols": [str(col) for col in leftSideData.dtypes],
                                  "right_df_cols": [str(col) for col in rightSideData.dtypes],
                                  "left_key_cols": leftKeys if isinstance(leftKeys, list) else [leftKeys],
                                  "right_key_cols": rightKeys if isinstance(rightKeys, list) else [
                                      rightKeys],
                                  "final_df_cols": [str(col) for col in data.dtypes], "target_tables": id(data),
                                  "source_tables": [id(leftSideData), id(rightSideData)],
                                  "left_df_id": str(id(leftSideData)), "right_df_id": str(id(rightSideData))})
            self.logger.info("Finished")
            return data
        except Exception:
            self.logger.error('Error while attempting to join datasets')
            traceback.print_exc()
            raise

    # Perform a left outer join on the given tables.
    # Pass column keys in as list to keyColumns (if column names are the same)

    def leftJoin(self, leftSideData, rightSideData, keyColumns, suffixes=None):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("left join two dataframes")

        if not isinstance(leftSideData, DataFrame):
            raise TypeError('leftSideData passed in is not list')

        if not isinstance(rightSideData, DataFrame):
            raise TypeError('rightSideData passed in is not list')

        if not isinstance(keyColumns, list) and not isinstance(keyColumns, str):
            raise TypeError('keyColumns passed in is not list')

        if suffixes is not None and not isinstance(suffixes, list):
            raise TypeError('suffixes passed in is not list')

        try:
            if isinstance(keyColumns, list):
                rightcol = rightSideData.columns
                for col in keyColumns:
                    rightcol.remove(col)
            elif isinstance(keyColumns, str):
                rightcol = rightSideData.columns
                rightcol.remove(keyColumns)
            else:
                raise TypeError("keyColumns not a recognized data type")
            correctorder = leftSideData.columns + rightcol
            resultData = leftSideData.join(rightSideData, keyColumns, 'left').select(correctorder)
            insert_dynamo_record(self.job_name, "leftJoin", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"left_df_cols": [str(col) for col in leftSideData.dtypes],
                                  "right_df_cols": [str(col) for col in rightSideData.dtypes],
                                  "key_cols": keyColumns if isinstance(keyColumns, list) else [keyColumns],
                                  "final_df_cols": [str(col) for col in resultData.dtypes],
                                  "target_tables": id(resultData),
                                  "source_tables": [id(leftSideData), id(rightSideData)],
                                  "left_df_id": str(id(leftSideData)), "right_df_id": str(id(rightSideData))})
            self.logger.info("Finished")
            return resultData
        except Exception:
            self.logger.error('Error while attempting to leftJoin datasets')
            traceback.print_exc()
            raise

    # Perform an inner join on the given tables. Pass column keys in as list to
    # keyColumns if column names are the same.

    def innerJoin(self, leftSideData, rightSideData, keyColumns, suffixes=None):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("inner join two dataframes")

        if not isinstance(leftSideData, DataFrame):
            raise TypeError('leftSideData passed in is not list')

        if not isinstance(rightSideData, DataFrame):
            raise TypeError('rightSideData passed in is not list')

        if not isinstance(keyColumns, list) and not isinstance(keyColumns, str):
            raise TypeError('keyColumns passed in is not list')

        if suffixes is not None and not isinstance(suffixes, list):
            raise TypeError('suffixes passed in is not list')

        try:
            if isinstance(keyColumns, list):
                rightcol = rightSideData.columns
                for col in keyColumns:
                    rightcol.remove(col)
            elif isinstance(keyColumns, str):
                rightcol = rightSideData.columns
                rightcol.remove(keyColumns)
            else:
                raise TypeError("keyColumns not a recognized data type")
            correctorder = leftSideData.columns + rightcol
            resultData = leftSideData.join(rightSideData, keyColumns, 'inner').select(correctorder)
            insert_dynamo_record(self.job_name, "innerJoin", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"left_df_cols": [str(col) for col in leftSideData.dtypes],
                                  "right_df_cols": [str(col) for col in rightSideData.dtypes],
                                  "key_cols": keyColumns if isinstance(keyColumns, list) else [keyColumns],
                                  "final_df_cols": [str(col) for col in resultData.dtypes],
                                  "target_tables": id(resultData),
                                  "source_tables": [id(leftSideData), id(rightSideData)],
                                  "left_df_id": str(id(leftSideData)), "right_df_id": str(id(rightSideData))})
            self.logger.info("Finished")
            return resultData
        except Exception:
            self.logger.error('Error while attempting to leftJoin datasets')
            traceback.print_exc()
            raise

    # Perform a full outer join on the given tables.
    # Pass column keys in as list to keyColumns (if column names are the same).

    def outerJoin(self, leftSideData, rightSideData, keyColumns, suffixes):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("outer join two dataframes")

        if not isinstance(leftSideData, DataFrame):
            raise TypeError('leftSideData passed in is not list')

        if not isinstance(rightSideData, DataFrame):
            raise TypeError('rightSideData passed in is not list')

        if not isinstance(keyColumns, list) and not isinstance(keyColumns, str):
            raise TypeError('keyColumns passed in is not list')

        if not isinstance(suffixes, list):
            raise TypeError('suffixes passed in is not list')

        try:
            if isinstance(keyColumns, list):
                rightcol = rightSideData.columns
                for col in keyColumns:
                    rightcol.remove(col)
            elif isinstance(keyColumns, str):
                rightcol = rightSideData.columns
                rightcol.remove(keyColumns)
            else:
                raise TypeError("keyColumns not a recognized data type")
            correctorder = leftSideData.columns + rightcol
            resultData = leftSideData.join(rightSideData, keyColumns, 'outer').select(correctorder)
            insert_dynamo_record(self.job_name, "outerJoin", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"left_df_cols": [str(col) for col in leftSideData.dtypes],
                                  "right_df_cols": [str(col) for col in rightSideData.dtypes],
                                  "key_cols": keyColumns if isinstance(keyColumns, list) else [keyColumns],
                                  "final_df_cols": [str(col) for col in resultData.dtypes],
                                  "target_tables": id(resultData),
                                  "left_df_id": str(id(leftSideData)), "right_df_id": str(id(rightSideData))})
            self.logger.info("Finished")
            return resultData
        except Exception:
            self.logger.error('Error while attempting to outerJoin datasets')
            traceback.print_exc()
            raise

    # Perform a left join, but where the key is not unique in the right-hand table,
    # arbitrarily choose the first row and ignore others.

    def lkpJoin(self, leftSideData, rightSideData, keyColumns=None, leftKeys=None, rightKeys=None, leftPrefix=None,
                rightPrefix=None):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("lkp join two dataframes")

        if not isinstance(leftSideData, DataFrame):
            raise TypeError('leftSideData passed in is not list')

        if not isinstance(rightSideData, DataFrame):
            raise TypeError('rightSideData passed in is not list')

        try:
            window = Window.orderBy(keyColumns).partitionBy(keyColumns)
            rightSideData = rightSideData.withColumn("row", F.row_number().over(window)).filter(F.col("row") == 1).drop(
                "row")

            if isinstance(leftKeys, list) and isinstance(rightKeys, list):
                joincondition = []
                for idx in range(0, len(leftKeys)):
                    joincondition.append(leftSideData[leftKeys[idx]] == rightSideData[rightKeys[idx]])

            elif isinstance(leftKeys, str) and isinstance(rightKeys, str):
                joincondition = (leftSideData[leftKeys[idx]] == rightSideData[rightKeys[idx]])

            elif leftKeys == None and rightKeys == None and isinstance(keyColumns, list):
                joincondition = []
                for idx in keyColumns:
                    joincondition.append(leftSideData[idx] == rightSideData[idx])

            elif isinstance(keyColumns, str):
                joincondition = (leftSideData[keyColumns] == rightSideData[keyColumns])

            rightcol = rightSideData.columns
            for col in keyColumns:
                rightcol.remove(col)
            correctorder = leftSideData.columns + rightcol
            data = leftSideData.join(rightSideData, joincondition, 'left').select(correctorder)
            insert_dynamo_record(self.job_name, "lkpJoin", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"left_df_cols": [str(col) for col in leftSideData.dtypes],
                                  "right_df_cols": [str(col) for col in rightSideData.dtypes],
                                  "key_cols": keyColumns if isinstance(keyColumns, list) else [keyColumns],
                                  "final_df_cols": [str(col) for col in data.dtypes], "target_tables": id(data),
                                  "left_df_id": str(id(leftSideData)), "right_df_id": str(id(rightSideData))})
            self.logger.info("Finished")
            return data
        except Exception:
            self.logger.error('Error while attempting to lookupjoin datasets')
            traceback.print_exc()
            raise

    # Return rows from the left table where the key value does not occur in the
    # right table.

    def antiJoin(self, leftSideData, rightSideData, keyColumns):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("anti join two dataframes")

        if not isinstance(leftSideData, DataFrame):
            raise TypeError('leftSideData is not a Dataframe')

        if not isinstance(rightSideData, DataFrame):
            raise TypeError('rightSideData is not a Dataframe')

        if not isinstance(keyColumns, list):
            raise TypeError('keyColumns is not a list')

        try:
            antiJoinData = leftSideData.join(rightSideData, keyColumns[0], "leftanti").select(leftSideData.columns)
            insert_dynamo_record(self.job_name, "antiJoin", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"left_df_cols": [str(col) for col in leftSideData.dtypes],
                                  "right_df_cols": [str(col) for col in rightSideData.dtypes],
                                  "key_cols": keyColumns if isinstance(keyColumns, list) else [keyColumns],
                                  "final_df_cols": [str(col) for col in antiJoinData.dtypes],
                                  "target_tables": id(antiJoinData),
                                  "left_df_id": str(id(leftSideData)), "right_df_id": str(id(rightSideData))})
            self.logger.info("Finished")
            return antiJoinData
        except Exception:
            self.logger.error('Error while performing antiJoin')
            traceback.print_exc()
            raise

    # Perform left join on dataframes that do not have a column name in common

    def leftJoinDifferentKeyNames(self, leftSideData, rightSideData, leftKeyColumns, rightKeyColumns, suffixes=None):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("left join two dataframes with different key names")

        if not isinstance(leftSideData, DataFrame):
            raise TypeError('leftSideData passed in is not list')

        if not isinstance(rightSideData, DataFrame):
            raise TypeError('rightSideData passed in is not list')

        if not isinstance(leftKeyColumns, list):
            raise TypeError('leftKeyColumns passed in is not list')

        if not isinstance(rightKeyColumns, list):
            raise TypeError('rightKeyColumns passed in is not list')

        if suffixes is not None and not isinstance(suffixes, DataFrame):
            raise TypeError('suffixes passed in is not list')

        try:
            rightcol = rightSideData.columns
            correctorder = leftSideData.columns + rightcol

            joincondition = []
            for idx in range(0, len(leftKeyColumns)):
                joincondition.append(leftSideData[leftKeyColumns[idx]] == rightSideData[rightKeyColumns[idx]])

            resultData = leftSideData.join(rightSideData, joincondition, 'left').select(correctorder)
            insert_dynamo_record(self.job_name, "leftJoinDifferentKeyNames", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"left_df_cols": [str(col) for col in leftSideData.dtypes],
                                  "right_df_cols": [str(col) for col in rightSideData.dtypes],
                                  "left_key_cols": leftKeyColumns if isinstance(leftKeyColumns, list) else [
                                      leftKeyColumns],
                                  "right_key_cols": rightKeyColumns if isinstance(rightKeyColumns, list) else [
                                      rightKeyColumns],
                                  "final_df_cols": [str(col) for col in resultData.dtypes],
                                  "target_tables": id(resultData),
                                  "source_tables": [id(leftSideData), id(rightSideData)],
                                  "left_df_id": str(id(leftSideData)), "right_df_id": str(id(rightSideData))})
            self.logger.info("Finished")
            return resultData
        except Exception:
            self.logger.error('Error while attempting to leftJoin datasets')
            traceback.print_exc()
            raise

    # Return rows in leftSideData that are not in rightSideData.

    def complement(self, leftSideData, rightSideData):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("complement two dataframes")
        self.logger.info("complement")

        if not isinstance(leftSideData, DataFrame):
            raise TypeError('leftSideData is not a list')

        if not isinstance(rightSideData, DataFrame):
            raise TypeError('rightSideData is not a list')
        try:
            complementData = leftSideData.subtract(rightSideData.select(leftSideData.schema.names))
            insert_dynamo_record(self.job_name, "complement", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"left_df_cols": [str(col) for col in leftSideData.dtypes],
                                  "right_df_cols": [str(col) for col in rightSideData.dtypes],
                                  "final_df_cols": [str(col) for col in complementData.dtypes],
                                  "target_tables": id(complementData),
                                  "source_tables": [id(leftSideData), id(rightSideData)],
                                  "left_df_id": str(id(leftSideData)), "right_df_id": str(id(rightSideData))})
            self.logger.info("Finished")
            return complementData
        except Exception:
            self.logger.error('Error while performing complement')
            traceback.print_exc()
            raise

    # Remove specified fields from dataframe (drop).

    def cutOut(self, data, columnNames):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("drop columns in dataframe")
        cols_before_drop = [str(col) for col in data.dtypes]
        if not isinstance(data, DataFrame):
            raise TypeError('data passed in is not list')

        try:
            new_data = data.drop(*columnNames)
            insert_dynamo_record(self.job_name, "cutOut", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"selected_cols": cols_before_drop, "dropped_cols": columnNames,
                                  "source_tables": [id(data)],
                                  "final_df_cols": [str(col) for col in new_data.dtypes],
                                  "target_tables": id(new_data)})
            self.logger.info("Finished")
            return new_data
        except Exception:
            self.logger.error('Error while attempting to cutout columns from data set')
            traceback.print_exc()
            raise

    # Select rows from the given dataframe that evaluate select condition.

    def selectRows(self, data, select, *involvedCols):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("filter rows in dataframe")

        if not isinstance(data, DataFrame):
            self.logger.error('data passed in is not list')
            raise TypeError()

        if not isinstance(select, T.BooleanType) and not isinstance(select, str):
            self.logger.error('select passed in is not lambda or string')
            raise TypeError()

        if isinstance(select, types.LambdaType) and involvedCols is None:
            self.logger.error("did not select columns to apply condition")
            raise TypeError()

        try:
            if isinstance(select, str):
                new_data = data.filter(select)
            elif isinstance(select, types.LambdaType):
                new_data = data.addComputedField(data, "_condition", select, *involvedCols).filter(
                    "_condition == True").drop("_condition")
            insert_dynamo_record(self.job_name, "selectRows", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"selected_cols": [str(col) for col in data.dtypes],
                                  "source_tables": [id(data)],
                                  "final_df_cols": [str(col) for col in new_data.dtypes],
                                  "target_tables": id(new_data)})
            self.logger.info("Finished")
            return new_data
        except Exception:
            self.logger.error('Error while attempting to select rows')
            traceback.print_exc()
            raise

    # Convert the DataFrame to a dictionary by passing in a key and a value column.

    def dfToDict(self, data, keyColumn, valueColumn, dict={}):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("get dictionary from dataframe columns")

        if not isinstance(data, DataFrame):
            self.logger.error('data passed in is not list')
            raise TypeError()

        if not isinstance(keyColumn, str) or not isinstance(valueColumn, str):
            self.logger.error('column name passed in is not string')

        try:
            for row in data.select(keyColumn, valueColumn).collect():
                dict[row[keyColumn]] = row[valueColumn]

            return dict
        except Exception:
            self.logger.error('Error in assigning dict')
            traceback.print_exc()
            raise Exception

    # Convert dataframe column to list object

    def columnToListRemoveDuplicates(self, data, colName):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Convert dataframe column to list object")

        if not isinstance(data, DataFrame):
            self.logger.error('data passed in is not list')
            raise TypeError()

        if not isinstance(colName, str):
            self.logger.error('column name passed in is not string')

        try:
            return [row[0] for row in data.select(colName).distinct().collect()]
        except Exception:
            self.logger.error('Error in converting column to list')
            traceback.print_exc()
            raise Exception

    # This function will create a surrogate key by connecting to a database and pulling its data into a dataframe.

    def getLkpSurrogateKeyValue(self, lkpTableName, schemaName, lkpNaturalKeyColumns, lkpSurrogateKeyColumn,
                                targetForeignKeyColumn, sourceDataJoinColumns,
                                sourceData, secret_name, source_type, source_database_type, env_type, joinType):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("create a surrogate key by connecting to a database and pulling its data into a dataframe")

        if not isinstance(schemaName, str):
            raise TypeError('schemaName passed in is not string')

        if not isinstance(lkpTableName, str):
            raise TypeError('lkpTableName passed in is not string')

        if not isinstance(lkpSurrogateKeyColumn, str):
            raise TypeError(
                'lkpSurrogateKeyColumn passed in is not string')

        if not isinstance(joinType, str):
            raise TypeError('joinType passed in is not string')

        if not isinstance(targetForeignKeyColumn, str):
            raise TypeError(
                'targetForeignKeyColumn passed in is not string')

        if not isinstance(lkpNaturalKeyColumns, list):
            raise TypeError(
                'lkpNaturalKeyColumns passed in is not list')

        if not isinstance(sourceDataJoinColumns, list):
            raise TypeError(
                'sourceDataJoinColumns passed in is not list')

        if not isinstance(sourceData, DataFrame):
            raise TypeError('sourceData passed in is not a list')

        if len(sourceDataJoinColumns) != len(lkpNaturalKeyColumns):
            raise TypeError(
                'Natural key columns on lookup table are not equal to join columns in source data')

        try:
            selectColumns = lkpNaturalKeyColumns + [lkpSurrogateKeyColumn]
            lkpExtractQuery = 'select ' + ','.join(selectColumns) + ' from ' + schemaName + '.' + lkpTableName
            config_dict = {
                "source_type": source_type,
                "source_database_type": source_database_type,
                "source_environments": '[{"environment_name": "{}", "database_secret_manager_name": "{}"}]'.format(
                    env_type, secret_name),
                "source_query": lkpExtractQuery
            }
            #src_dict = InventoryReader(config_dict).get_source_connector_config()
            src_dict = {}
            #src_connector = ConnectorSupplier(env_type).get_connector(src_dict)
            src_connector = None
            lkpData = src_connector.read_data()
            columnDict = dict(zip(lkpNaturalKeyColumns, sourceDataJoinColumns))
            renamedLkpData = rename(lkpData, columnDict)
            sourceHeader = sourceData.schema.names
            dataDf = sourceData
            lkpDf = renamedLkpData
            sourceData = dataDf.join(lkpDf, on=sourceDataJoinColumns, how=joinType)
            sourceHeader = sourceHeader.append(lkpSurrogateKeyColumn)
            for key in sourceDataJoinColumns:
                sourceData = cutOut(sourceData, key)

            return rename(sourceData, {lkpSurrogateKeyColumn: targetForeignKeyColumn})
        except Exception:
            self.logger.error('Error retrieving surrogate key')
            traceback.print_exc()
            raise

    # this function adds a surrogate key from a

    def getLkpSurrogateKeyValue(self, lkpData, lkpNaturalKeyColumns, lkpSurrogateKeyColumn, targetForeignKeyColumn,
                                sourceDataJoinColumns,
                                sourceData, joinType):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("adds a surrogate key")

        if not isinstance(lkpSurrogateKeyColumn, str):
            raise TypeError(
                'lkpSurrogateKeyColumn passed in is not string')

        if not isinstance(joinType, str):
            raise TypeError('joinType passed in is not string')

        if not isinstance(targetForeignKeyColumn, str):
            raise TypeError(
                'targetForeignKeyColumn passed in is not string')

        if not isinstance(lkpNaturalKeyColumns, list):
            raise TypeError(
                'lkpNaturalKeyColumns passed in is not list')

        if not isinstance(sourceDataJoinColumns, list):
            raise TypeError(
                'sourceDataJoinColumns passed in is not list')

        if not isinstance(sourceData, DataFrame):
            raise TypeError('sourceData passed in is not a list')

        if len(sourceDataJoinColumns) != len(lkpNaturalKeyColumns):
            raise TypeError(
                'Natural key columns on lookup table are not equal to join columns in source data')

        try:
            selectColumns = lkpNaturalKeyColumns + [lkpSurrogateKeyColumn]
            lkpData = lkpData.select(selectColumns)
            columnDict = dict(zip(lkpNaturalKeyColumns, sourceDataJoinColumns))
            renamedLkpData = rename(lkpData, columnDict)
            sourceHeader = sourceData.schema.names
            dataDf = sourceData
            lkpDf = renamedLkpData
            sourceData = dataDf.join(lkpDf, on=sourceDataJoinColumns, how=joinType)
            sourceHeader = sourceHeader.append(lkpSurrogateKeyColumn)
            for key in sourceDataJoinColumns:
                sourceData = cutOut(sourceData, key)

            return rename(sourceData, {lkpSurrogateKeyColumn: targetForeignKeyColumn})
        except Exception:
            self.logger.error('Error retrieving surrogate key')
            traceback.print_exc()
            raise

    # helper method for findFirstNonNullColumn

    def findFirstNonNull(self, *args):
        n = 0
        for a in args:
            if a in ['NR', 'WR', 'WD', 'PIF', 'nan', np.nan, None, '', 'N/A']:
                n += 1
                continue
            else:
                return a[n]
        return None

    # for every row, find the first non-null value and return that value as a new column.

    def findFirstNonNullColumn(self, data, colName, *cols):
        logger.debug("Transformation Util - findFirstNonNullColumn - find first value in row that is not null")
        return addComputedField(data, colName, lambda *x: findFirstNonNull(x), cols)

    # Transform values in one field via a lambda function.

    def conversion(self, data, columnName, conversion, dataType):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Transform values in one field via a lambda function")

        if not isinstance(data, DataFrame):
            raise TypeError('data passed in is not dataframe')

        if not isinstance(columnName, str):
            raise TypeError('columnName passed in is not string')

        if not isinstance(conversion, types.LambdaType):
            raise TypeError('conversion passed in is not lambda')

        if not isinstance(dataType, T.DataType):
            raise TypeError(
                'datatype is not an instance of pyspark.sql.types.DataType')

        try:
            if isinstance(columnName, str) and columnName in data.columns:
                new_data = data.withColumn(columnName, F.udf(conversion, dataType)(columnName))
            elif isinstance(columnName, list) or isinstance(columnName,
                                                            tuple):  ##check if more than one column name passed in
                new_data = data
                for col in columnName:
                    if col in data.columns:
                        new_data = new_data.withColumn(col, F.udf(conversion, dataType)(col))
                    else:
                        raise KeyError("" + col + " is not a valid column name")
            else:
                raise KeyError("error in input")
            insert_dynamo_record(self.job_name, "conversion", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"selected_cols": [str(col) for col in data.dtypes],
                                  "source_tables": [id(data)],
                                  "final_df_cols": [str(col) for col in new_data.dtypes],
                                  "target_tables": id(new_data)})
            self.logger.info("Finished")
            return data
        except Exception:
            self.logger.error('Error while attempting a conversion')
            traceback.print_exc()
            raise

    # apply conversion only to rows where condition is True

    def conditionalConversion(self, data, columnName, conversion, condition):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("apply conversion only to rows where condition is True")

        if not isinstance(data, DataFrame):
            raise TypeError('data passed in is not list')

        if not isinstance(columnName, str):
            raise TypeError('columnName passed in is not string')

        if not isinstance(conversion, types.LambdaType):
            raise TypeError('conversion passed in is not lambda')

        if not isinstance(condition, T.BooleanType) and not isinstance(condition, str):
            raise TypeError('condition passed in is not boolean')

        try:
            changedRows = data.filter(condition)
            sameRows = data.subtract(changedRows)
            new_data = changedRows.withColumn(columnName, F.udf(conversion)(columnName)).union(sameRows)
            insert_dynamo_record(self.job_name, "conditionalConversion", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"selected_cols": [str(col) for col in data.dtypes],
                                  "source_tables": [id(data)],
                                  "final_df_cols": [str(col) for col in new_data.dtypes],
                                  "target_tables": id(new_data)})
            self.logger.info("Finished")
            return new_data
        except Exception:
            self.logger.error(
                'Error while attempting a conditional conversion')
            traceback.print_exc()
            raise

    # converts column to pyspark.sql.types.FloatType

    def convertColumnToFloat(self, data, columnName):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("converts column to pyspark.sql.types.FloatType")

        try:
            convertedData = data.withColumn(columnName, data[columnName].cast("float"))
            insert_dynamo_record(self.job_name, "convertColumnToFloat", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"selected_cols": [str(col) for col in data.dtypes],
                                  "source_tables": [id(data)],
                                  "final_df_cols": [str(col) for col in convertedData.dtypes],
                                  "target_tables": id(convertedData)})
            self.logger.info("Finished")
            return convertedData
        except Exception:
            self.logger.error('Error while converting column into float')
            raise

    # converts column to pyspark.sql.types.IntegerType

    def convertColumnToInt(self, data, columnName):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("converts column to pyspark.sql.types.IntegerType")

        try:
            convertedData = data.withColumn(columnName, data[columnName].cast("int"))
            insert_dynamo_record(self.job_name, "convertColumnToInt", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"selected_cols": [str(col) for col in data.dtypes],
                                  "source_tables": [id(data)],
                                  "final_df_cols": [str(col) for col in convertedData.dtypes],
                                  "target_tables": id(convertedData)})
            self.logger.info("Finished")
            return convertedData
        except Exception:
            self.logger.error('Error while converting column into int')
            raise

    # converts column to pyspark.sql.types.StringType

    def convertColumnToString(self, data, columnName):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("converts column to pyspark.sql.types.StringType")

        try:
            convertedData = data.withColumn(columnName, data[columnName].cast("string"))
            insert_dynamo_record(self.job_name, "convertColumnToString", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"selected_cols": [str(col) for col in data.dtypes],
                                  "source_tables": [id(data)],
                                  "final_df_cols": [str(col) for col in convertedData.dtypes],
                                  "target_tables": id(convertedData)})
            self.logger.info("Finished")
            return convertedData
        except Exception:
            self.logger.error('Error while converting column into string')
            raise

    # sorts data by keyColumns passed in as list

    def sort(self, data, keyColumns, descOrder=False):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("sorts data by keyColumns passed in as list")

        if not isinstance(data, DataFrame):
            self.logger.error('data passed in is not list')
            raise TypeError()

        if not isinstance(keyColumns, list):
            self.logger.error('keyColumns passed in is not list')
            raise TypeError()

        if not isinstance(descOrder, bool):
            self.logger.error('descOrder passed in is not bool')
            raise TypeError()

        try:
            sortedData = data.sort(keyColumns, ascending=not descOrder)
            insert_dynamo_record(self.job_name, "sort", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"selected_cols": [str(col) for col in data.dtypes],
                                  "source_tables": [id(data)],
                                  "final_df_cols": [str(col) for col in sortedData.dtypes],
                                  "target_tables": id(sortedData)})
            self.logger.info("Finished")
            return sortedData
        except Exception:
            self.logger.error('Error while sorting data')
            raise

    # Group by the key field then return the first row within each group

    def groupSelectFirst(self, data, keyColumns):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Group by the key&field then return the first row within each group")

        if not isinstance(data, pyspark.sql.dataframe.DataFrame):
            self.logger.error('data passed in is not DataFrame')
            raise TypeError()

        if not isinstance(keyColumns, list) and not isinstance(keyColumns, str):
            self.logger.error('keyColumns passed in is not list')
            raise TypeError()

        try:
            window = Window.orderBy(keyColumns).partitionBy(keyColumns)
            groupedData = data.withColumn("row", F.row_number().over(window)).filter(F.col("row") == 1).drop("row")
            insert_dynamo_record(self.job_name, "groupSelectFirst", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"selected_cols": [str(col) for col in data.dtypes],
                                  "source_tables": [id(data)],
                                  "final_df_cols": [str(col) for col in groupedData.dtypes],
                                  "target_tables": id(groupedData)})
            self.logger.info("Finished")
            return groupedData
        except Exception:
            self.logger.error('Error while grouping data')
            raise

    # remove duplicate rows from the dataframe

    def removeDuplicates(self, dataObject):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("remove duplicate rows from the dataframe")

        if not isinstance(dataObject, DataFrame):
            raise TypeError('dataObject passed in is not DataFrame')
        try:
            new_data = dataObject.distinct()
            insert_dynamo_record(self.job_name, "removeDuplicates", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"selected_cols": [str(col) for col in dataObject.dtypes],
                                  "source_tables": [id(dataObject)],
                                  "final_df_cols": [str(col) for col in new_data.dtypes],
                                  "target_tables": id(new_data)})
            self.logger.info("Finished")
            return new_data
        except Exception:
            self.logger.error('Error while removing duplicates datasets')
            raise

    # construct a pivot table where the pivoted values are joined together in a comma-seperated list string

    def pivotAggregateData(self, inputData, indexcol, column, values):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("construct a pivot table")

        if not isinstance(inputData, DataFrame):
            raise TypeError('dataObject passed in is not DataFrame')

        if not isinstance(indexcol, str):
            raise TypeError('index passed in is not string')

        if not isinstance(column, str):
            raise TypeError('column passed in is not string')

        if not isinstance(values, str):
            raise TypeError('value passed in is not string')
        try:
            pivotedData = inputData.groupBy(indexcol)

            if pivotedData.count() == 0:
                pivotedData = inputData
            else:
                pivotedData = pivotedData.pivot(column).agg(F.concat_ws(',', F.collect_list(values)))
            insert_dynamo_record(self.job_name, "pivotAggregateData", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"selected_cols": [str(col) for col in inputData.dtypes],
                                  "source_tables": [id(inputData)],
                                  "final_df_cols": [str(col) for col in pivotedData.dtypes],
                                  "target_tables": id(pivotedData)})
            return pivotedData
        except Exception:
            self.logger.error('Error while pivoting datasets')
            raise

    # Construct a pivot table.

    def pivotTable(self, inputData, indexcol, column, values, aggfunc):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("construct a pivot table")

        if not isinstance(inputData, DataFrame):
            raise TypeError('dataObject passed in is not DataFrame')

        if not isinstance(aggfunc, str):
            raise TypeError('function passed in is not lambda')

        try:
            pivotedData = inputData.groupBy(indexcol)

            if pivotedData.count() == 0:
                pivotedData = inputData
            else:
                pivotedData = pivotedData.pivot(column).agg({values: aggfunc})
            insert_dynamo_record(self.job_name, "pivotTable", self.job_environment,
                                 self.source_target_mapping, self.domain_name,
                                 {"selected_cols": [str(col) for col in inputData.dtypes],
                                  "source_tables": [id(inputData)],
                                  "final_df_cols": [str(col) for col in pivotedData.dtypes],
                                  "target_tables": id(pivotedData)})
            return pivotedData
        except Exception:
            self.logger.error('Error while pivoting datasets')
            raise


    def sparkSql(self, sql_query, src_tables):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("run a sql query using sparkSql")

        if not isinstance(sql_query, str):
            raise TypeError('sql query passed in is not string')
        try:
            df = self.spark.sql(sql_query)
            insert_dynamo_record(self.job_name, "sparkSql", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"sql_text": sql_query, "final_df_cols": [str(col) for col in df.dtypes],
                                  "target_tables": id(df), "source_tables": src_tables})
            return df
        except Exception:
            self.logger.error('Error while creating df using sql query')
            raise


    def createTargetTable(self, pipeline_id, final_entity_df, final_path_out, app_name, aws_region):
        self.logger.info(f'Started at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self.logger.info("Create target table using athena util")

        if not isinstance(final_entity_df, DataFrame):
            raise TypeError('Data should be of type Dataframe')
        try:
            athena_util.AthenaUtil.create_athena_processed_table(pipeline_id, final_entity_df, final_path_out,
                                                                 app_name,
                                                                 self.domain_name, aws_region, self.job_environment)
            insert_dynamo_record(self.job_name, "Final", self.job_environment, self.source_target_mapping,
                                 self.domain_name,
                                 {"final_df_cols": [
                                     # str(col) if not col[1].startswith('decimal') else f"('{col[0]}', 'decimal')" for
                                     str(col) for col in final_entity_df.dtypes],
                                  "source_tables": [id(final_entity_df)],
                                  "target_tables": final_path_out.split('/')[-1] if len(
                                      final_path_out.split('/')[-1]) > 1 else final_path_out.split('/')[-2],
                                     "final_path": final_path_out})
            return
        except Exception:
            self.logger.error('Error while creating df using sql query')
            raise
