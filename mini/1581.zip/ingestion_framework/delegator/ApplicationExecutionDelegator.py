import boto3

from ingestion_framework.services.ApplicationExecutionService import ApplicationExecutionService
from ingestion_framework.services.SparkService import SparkService
from ingestion_framework.services.LoggerService import LoggerService


class ApplicationExecutionDelegator:

    @staticmethod
    def get_logger():
        return LoggerService.get_root_logger()


    @staticmethod
    def run_application(app_name, run_all_pipelines_flag, pipeline_id, pipeline_version, job_env, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, run_in_sequence_flag, parallel_pipelines_limit, logger):
        # Initializing spark and Logger
        print(f'level 3- app_name:{app_name}')
        aws_region = boto3.session.Session().region_name
        spark = SparkService.get_spark_session(app_name, logger)

        ApplicationExecutionService.log_application_parameters(app_name, aws_region, run_all_pipelines_flag, pipeline_id, pipeline_version, job_env, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, run_in_sequence_flag, parallel_pipelines_limit, logger)
        
        ApplicationExecutionService.validate_application_parameters(app_name, aws_region, run_all_pipelines_flag, pipeline_id, pipeline_version, job_env, logger)
    
        pipelineids_with_versions = ApplicationExecutionService.compute_pipelineids_with_versions(app_name, run_all_pipelines_flag, pipeline_id, pipeline_version, logger)

        if  run_in_sequence_flag == "true":
            pipeline_response_list = ApplicationExecutionService.trigger_pipelines_in_sequence(pipelineids_with_versions, app_name, job_env, aws_region, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, spark, logger)
        else:
            pipeline_response_list = ApplicationExecutionService.trigger_pipelines_in_parallel(pipelineids_with_versions, app_name, job_env, aws_region, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, parallel_pipelines_limit, spark, logger)

        ApplicationExecutionService.log_pipeline_response(pipeline_response_list, logger)

        return pipeline_response_list