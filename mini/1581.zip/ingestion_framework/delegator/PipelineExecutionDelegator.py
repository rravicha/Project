import traceback
from datetime import datetime
from pytz import timezone

from ingestion_framework.services.JobStatusService import JobStatusService
from ingestion_framework.services.YamlService import YamlService
from ingestion_framework.services.OlaService import OlaService
from ingestion_framework.services.SlaService import SlaService
from ingestion_framework.services.ETLService import ETLService
from ingestion_framework.mapper.PipelineMapper import PipelineMapper
from ingestion_framework.mapper.PipelineResponseMapper import PipelineResponseMapper
from ingestion_framework.enums.JobParameters import JobParameters


class PipelineExecutionDelegator:

    @staticmethod
    def run_pipeline(app_name, pipeline_id, pipeline_version, job_env, aws_region, business_start_datetime, business_end_datetime, spark, logger):
        jobstatus_result = None
        sla_met = False
        logger.info(f"{pipeline_id} - Execution started")
        
        pipeline_info = YamlService(logger).read_pipeline_info_from_application_yaml(app_name, pipeline_id, pipeline_version)   
        logger.info(f'{pipeline_id} - Fetched the pipeline dictionary from yaml file')
        
        pipeline = PipelineMapper(logger).map_pipeline(pipeline_info)
        logger.info(f'{pipeline_id} - Converted the pipeline dictionary to Pipeline model object')
        
        job_start_datetime = datetime.now(timezone('US/Eastern'))
        jobstatus_entry = JobStatusService(logger).put_jobstatus_entry(pipeline, job_start_datetime, job_env, aws_region)
        logger.info(f'{pipeline_id} - Initial job status entry was put in JobStatus table')
        
        try:
            OlaService.validate_ola(pipeline_id, pipeline.metadata.ola, logger)
            logger.info(f'{pipeline_id} - Validated OLA')
            
            data, business_start_datetime, business_end_datetime = ETLService(spark, logger, job_env, aws_region, pipeline, business_start_datetime, business_end_datetime).run_etl()
            logger.info(f'{pipeline_id} - Created source and target connector objects')
        
            job_end_datetime = datetime.now(timezone('US/Eastern'))
            sla_met = SlaService.validate_sla(pipeline_id, job_start_datetime, job_end_datetime, pipeline.metadata.sla, logger)
            logger.info(f'{pipeline_id} - Validated SLA')

            jobstatus_result = JobStatusService(logger).update_jobstatus_entry(jobstatus_entry, pipeline_id, str(business_start_datetime), str(business_end_datetime), str(job_end_datetime.strftime("%Y-%m-%d %H:%M:%S")), JobParameters.SUCCESS_FLAG.value, 0, data.count(), 0, sla_met, '', job_env, aws_region)
            logger.info(f'{pipeline_id} - Updated the job status entry')        

        except Exception as err:
            logger.error(f'{pipeline_id} - Failed with error: {err}')
            job_end_datetime = datetime.now(timezone('US/Eastern'))
            jobstatus_result = JobStatusService(logger).update_jobstatus_entry(jobstatus_entry, pipeline_id, str(business_start_datetime), str(business_end_datetime), str(job_end_datetime.strftime("%Y-%m-%d %H:%M:%S")), JobParameters.FAILURE_FLAG.value, 0, 0, 0, sla_met, str(err), job_env, aws_region)
            logger.error(f'{pipeline_id} - Updated the job status entry')  
            traceback.print_exc()      

        finally:
            pipeline_response = PipelineResponseMapper(logger).map_jobstatus_result_to_pipeline_response(jobstatus_result) 
            logger.info(f"{pipeline_id} - Execution completed")
            return pipeline_response


    @staticmethod
    def compute_business_start_and_end_datetime(pipeline_id, job_env, aws_region, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, spark, logger):
        business_start_datetime_list = []
        business_end_datetime_list = []

        if run_in_daily_chunks_flag.lower() == "true":
            if business_start_datetime:
                start_date = business_start_datetime.split(' ')[0]
            else:
                last_successul_business_start_datetime = JobStatusService(logger).get_last_successul_business_start_datetime(spark, pipeline_id, job_env, aws_region)
                if not last_successul_business_start_datetime:
                    start_date = last_successul_business_start_datetime.split(' ')[0]
                else:
                    logger.error(f"{pipeline_id} - Run in chunks is enabled. Business Start Date is not provided. Previous execution for this pipeline in Jobstatus is not found. So start date is unknown.")
                    raise Exception(f"{pipeline_id} - Run in chunks is enabled. Business Start Date is not provided. Previous execution for this pipeline in Jobstatus is not found. So start date is unknown.")

            end_date = business_end_datetime.split(' ')[0] if business_end_datetime != "" else str(datetime.now()).split(' ')[0]

            computed_dates_list = get_delta_days(start_date, end_date)

            for date in computed_dates_list:
                if str(date) == str(end_date):
                    business_end_datetime_list.append(business_end_datetime if business_end_datetime != "" else str(datetime.now()))
                else:
                    business_end_datetime_list.append(str(date)+" 23:59:59")

                
                if str(date) == str(start_date) and business_start_datetime != "":
                    business_start_datetime_list.append(business_start_datetime)
                elif str(date) == str(start_date) and business_start_datetime == "":
                    business_start_datetime_list.append(last_successul_business_start_datetime)
                else:
                    business_start_datetime_list.append(str(date)+" 00:00:00")
        else:
            business_start_datetime_list.append(business_start_datetime)
            business_end_datetime_list.append(business_end_datetime)

        return business_start_datetime_list, business_end_datetime_list


    @staticmethod
    def get_delta_days(job_start_datetime, job_end_datetime):
        start_dt = date(int(job_start_datetime.split('-')[0]), int(job_start_datetime.split('-')[1]), int(job_start_datetime.split('-')[2]))
        end_dt = date(int(job_end_datetime.split('-')[0]), int(job_end_datetime.split('-')[1]), int(job_end_datetime.split('-')[2]))
        delta = end_dt - start_dt
        days = [start_dt + timedelta(days=i) for i in range(delta.days + 1)]
        days = [str(dt.strftime("%Y-%m-%d")) for dt in days]
        print(f"App Runner - total no of days to process = {len(days)}")
        return days