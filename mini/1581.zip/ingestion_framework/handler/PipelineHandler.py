from ingestion_framework.delegator.PipelineExecutionDelegator import PipelineExecutionDelegator

class PipelineHandler:
    @staticmethod
    def run_pipeline(app_name, pipeline_id, pipeline_version, job_env, aws_region, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, spark, logger):
        logger.info(f"{pipeline_id} - Execution started")
        
        business_start_datetime_list, business_end_datetime_list = PipelineExecutionDelegator.compute_business_start_and_end_datetime(pipeline_id, job_env, aws_region, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, spark, logger)

        pipeline_response_list = []
        for start_datetime, end_datetime in zip(business_start_datetime_list, business_end_datetime_list):
            pipeline_response = PipelineExecutionDelegator.run_pipeline(app_name, pipeline_id, pipeline_version, job_env, aws_region, start_datetime, end_datetime, spark, logger)

            pipeline_response_list.append(pipeline_response)

            if pipeline_response.jobstatus.lower() == "failure":
                break

        logger.info(f"{pipeline_id} - Received PipelineResponse object")

        logger.info(f"{pipeline_id} - Execution completed")
        return pipeline_response_list