from ingestion_framework.delegator.ApplicationExecutionDelegator import ApplicationExecutionDelegator


class ApplicationHandler:

    @staticmethod
    def run_application(app_name, run_all_pipelines_flag, pipeline_id, pipeline_version, job_env, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, run_in_sequence_flag, parallel_pipelines_limit):
        print(f'level 2- app_name:{app_name}')
        logger = ApplicationExecutionDelegator().get_logger()

        logger.info(f"{app_name} - Execution started")
        
        pipeline_response_list = ApplicationExecutionDelegator.run_application(app_name, run_all_pipelines_flag, pipeline_id, pipeline_version, job_env, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, run_in_sequence_flag, parallel_pipelines_limit, logger)
        logger.info(f"{app_name} - Received PipelineResponse objects")

        failed_pipelines = []
        for pipeline_response in pipeline_response_list:
            if pipeline_response.jobstatus.lower() == "failure":
                failed_pipelines.append(pipeline_response.id)

        if len(failed_pipelines) > 0:
            logger.error(f"{app_name} - Failed pipelines are : {failed_pipelines}")
            logger.info(f"{app_name} - Execution completed")
            raise SystemExit(f'{app_name} - Failed pipelines are : {failed_pipelines}')

        logger.info(f"{app_name} - Execution completed")