from ingestion_framework.repository.JobStatusRepository import JobStatusRepository
from ingestion_framework.mapper.JobStatusEntryMapper import JobStatusEntryMapper


class JobStatusService:
    def __init__(self, logger):
        self.logger = logger


    def get_last_successul_business_start_datetime(self, spark, pipeline_id, job_env, aws_region):
        return JobStatusRepository(self.logger).get_last_successul_business_start_datetime(spark, pipeline_id, job_env, aws_region)


    def get_jobstatus_entries_for_pipeline(self, pipeline_id, job_env, aws_region):
        return JobStatusRepository(self.logger).get_jobstatus_entries_for_pipeline(pipeline_id, job_env, aws_region)


    def update_jobstatus_entry(self, jobstatus_entry, pipeline_id, business_start_datetime, business_end_datetime, job_end_datetime, jobstatus_flag, landing_count, final_count, processed_count, sla_met, error_message, job_env, aws_region):
        self.logger.info(f"{pipeline_id} - Started")
        
        updated_jobstatus_entry = JobStatusEntryMapper(self.logger).update_jobstatus_entry(jobstatus_entry, business_start_datetime, business_end_datetime, job_end_datetime, jobstatus_flag, landing_count, final_count, processed_count, sla_met, error_message)
        self.logger.info(f"{pipeline_id} - Updated JobStatus entry")
        
        JobStatusRepository(self.logger).update_jobstatus_entry(pipeline_id, updated_jobstatus_entry, job_env, aws_region)
        self.logger.info(f"{pipeline_id} - Succeeded")
        
        return updated_jobstatus_entry


    def put_jobstatus_entry(self, pipeline, job_start_datetime, job_env, aws_region):
        pipeline_id = pipeline.metadata.id
        self.logger.info(f"{pipeline_id} - Started")
        
        jobstatus_entry = JobStatusEntryMapper(self.logger).generate_initial_entry(pipeline, job_start_datetime, job_env)
        self.logger.info(f"{pipeline_id} - Generated JobStatus entry")
        
        JobStatusRepository(self.logger).put_jobstatus_entry(pipeline_id, jobstatus_entry, job_env, aws_region)
        self.logger.info(f"{pipeline_id} - Succeeded")
        
        return jobstatus_entry
    