class ETLService:
    def __init__(self, spark, logger, job_env, aws_region, pipeline, business_start_datetime, business_end_datetime):
        self.spark = spark
        self.logger = logger
        self.job_env = job_env
        self.aws_region = aws_region
        self.pipeline_metadata = pipeline.metadata
        self.app_name = pipeline.application.name
        self.domain_name = pipeline.domain.name
        self.resources = pipeline.resources
        self.business_start_datetime = business_start_datetime
        self.business_end_datetime = business_end_datetime
        self.pipeline_id = pipeline.metadata.id
    
    
    def run_etl(self):
        source_connector, target_connector = self.create_connectors()
        
        source_data, business_start_datetime, business_end_datetime = source_connector.read_data()
        
        target_data = target_connector.write_data(source_data)
        
        return target_data, business_start_datetime, business_end_datetime
    

    def create_connectors(self):
        self.logger.info(f"{self.pipeline_id} - Started")
        
        source_connector = None
        target_connector = None
        
        for resource in self.resources:
            connector_name = resource.metadata.resource_type
            self.logger.info(f"{self.pipeline_id} - Creating {connector_name} connector")
            
            connector_class_name = connector_name.title() + "Connector"
            connector_path = f"ingestion_framework.repository.connectors.{connector_class_name}"
            self.logger.info(f"{self.pipeline_id} - connector path: {connector_path}")
            connector_module = __import__(connector_path)
            self.logger.info(f"{self.pipeline_id} - connector module : {connector_module}")
            connector_class = getattr(connector_module, connector_class_name)
            self.logger.info(f"{self.pipeline_id} - connector class: {connector_class}")
            connector = connector_class(self.pipeline_metadata, self.app_name, self.domain_name, resource, self.job_env, self.aws_region, self.business_start_datetime, self.business_end_datetime, self.spark, self.logger)
            
            if resource.flag == "source":
                source_connector = connector
            else:
                target_connector = connector
            
            self.logger.info(f"{self.pipeline_id} - Creating {connector_name} connector successful")
        return source_connector, target_connector