import yaml

from ingestion_framework.enums.JobParameters import JobParameters
from ingestion_framework.enums.DynamodbEnum import DynamodbEnum


class YamlService:
    def __init__(self, logger):
        self.logger = logger
        
    def read_pipeline_info_from_application_yaml(self,app_name, pipeline_id, pipeline_version):
        yaml_file_name = f'{app_name}.{JobParameters.YAML.value}'
        with open(yaml_file_name, "r") as yaml_file:
            yaml_dict = yaml.load(yaml_file, Loader=yaml.SafeLoader)
        return next((pipeline for pipeline in yaml_dict[DynamodbEnum.PIPELINES.value] if pipeline["id"] == pipeline_id and pipeline["versionNumber"] == pipeline_version), None)

    def read_all_pipelines_info_from_application_yaml(self,app_name):
        yaml_file_name = f'{app_name}.{JobParameters.YAML.value}'
        with open(yaml_file_name, "r") as yaml_file:
            yaml_content = yaml.load(yaml_file, Loader=yaml.SafeLoader)
        return yaml_content[DynamodbEnum.PIPELINES.value]

    def get_all_pipelineids_with_latest_versions(self, app_name):
        pipelines = self.read_all_pipelines_info_from_application_yaml(app_name)
        pipelines_with_versions = {}
        for pipeline in pipelines:
            if pipeline["id"] in pipelines_with_versions:
                if pipeline["status"] == '' or pipeline["status"] == None :
                    pipeline["status"]  = "active"
                if pipeline["status"].lower() == "active" and pipeline["versionNumber"] > pipelines_with_versions[pipeline["id"]]:
                    pipelines_with_versions.update({pipeline["id"] : pipeline["versionNumber"]})
            else:
                if pipeline["status"]  == '' or pipeline["status"]  == None :
                    pipeline["status"]  = "active"
                if pipeline["status"].lower() == 'active'  :
                    pipelines_with_versions[pipeline["id"]] = pipeline["versionNumber"]
        
        return pipelines_with_versions