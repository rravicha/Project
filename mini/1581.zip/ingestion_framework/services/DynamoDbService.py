from ingestion_framework.repository.DynamoDbRepository import DynamoDbRepository

class DynamoDbService:
    @staticmethod
    def bulk_delete_by_sort_key(table_name, sort_key, partition_key, sk_values, aws_region, logger):
        # 1. Table Name is Mandatory
        if not table_name:
            raise SystemExit('Table Name is needed')

        # 2. Sort Key is Mandatory
        if not sort_key:
            raise SystemExit('Sort Key is needed')

        # 3. Partition Key is Mandatory
        if not partition_key:
            raise SystemExit('Partition Key is needed')

        # 4. Sort Key values are Mandatory
        if not sk_values:
            raise SystemExit('Sort Key Values are needed')

        logger.info('Execution started')
        DynamoDbRepository.bulk_delete_by_sort_key(table_name, sort_key, partition_key, sk_values, aws_region, logger)
        logger.info('Execution finished')