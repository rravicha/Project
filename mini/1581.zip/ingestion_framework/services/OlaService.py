import time
from datetime import datetime
from pytz import timezone


class OlaService:
    @staticmethod
    def validate_ola(pipeline_id, ola, logger):
        logger.info(f"{pipeline_id} - Started")
        
        ola_start_time = datetime.strptime(ola.start_time, '%H:%M:%S').time() if ola.start_time != '' else None
        ola_end_time = datetime.strptime(ola.end_time, '%H:%M:%S').time() if ola.end_time != '' else None
        
        logger.info(f"{pipeline_id} - Ola Start time: {ola_start_time}")
        logger.info(f"{pipeline_id} - Ola End time: {ola_end_time}")
        
        current_time = datetime.now(timezone('US/Eastern')).time()
        
        logger.info(f"{pipeline_id} - Current time: {current_time}")
        
        if ola_start_time and ola_end_time and (ola_start_time <= current_time <= ola_end_time):
            logger.error("{pipeline_id} - Failed - Aborted due to the job start time is between OLA time range")
            raise Exception("{pipeline_id} - Aborted due to the job start time is between OLA time range")
        
        logger.info(f"{pipeline_id} - Succeeded")