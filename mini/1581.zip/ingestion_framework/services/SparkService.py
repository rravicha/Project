from pyspark.sql import SparkSession

DEFAULT_SPARK_EXTRA_CLASS_PATH_CONFIG = '/code/jars/ojdbc8.jar' \
    +':'+'/code/jars/jconn4.jar' \
    +':'+'/code/jars/db2jcc4.jar' \
    +':'+'/code/jars/postgresql-42.2.20.jar' \
    +':'+'/code/jars/mysql-connector-java-8.0.22.jar'

class SparkService:

    @staticmethod
    def get_spark_session(app_name, logger):
        logger.info(f"{app_name} - Started")
        spark = SparkSession\
        .builder\
        .appName(app_name)\
        .config('spark.driver.extraClassPath', DEFAULT_SPARK_EXTRA_CLASS_PATH_CONFIG)\
        .config('spark.executor.extraClassPath', DEFAULT_SPARK_EXTRA_CLASS_PATH_CONFIG) \
        .getOrCreate()
        logger.info(f"{app_name} - Created the spark session")
        return spark
