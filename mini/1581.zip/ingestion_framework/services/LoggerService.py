import logging

class LoggerService:
    @staticmethod
    def get_root_logger():
        logging.basicConfig(format='%(asctime)s %(levelname)s - %(module)s - %(funcName)s - %(message)s', level=logging.INFO)
        return logging.getLogger(__name__)