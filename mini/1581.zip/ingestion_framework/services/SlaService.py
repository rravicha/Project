from datetime import timedelta

class SlaService:
    @staticmethod
    def validate_sla(pipeline_id, job_start_datetime, job_end_datetime, sla, logger):
        logger.info(f"{pipeline_id} - Started")
        
        if sla == "":
            return "not applicable"
        
        sla_in_seconds = SlaService.convert_duration_to_seconds(sla)
        
        job_run_time = job_end_datetime - job_start_datetime
        job_run_time_in_seconds = job_run_time.total_seconds()
        
        sla_met = sla_in_seconds > job_run_time_in_seconds
        
        logger.info(f"{pipeline_id} - Succeeded")
        
        return "true" if sla_met == True else "false"
    
    @staticmethod
    def convert_duration_to_seconds(duration):
        #Duration in the format --> hh:mm:ss
        hours, minutes, seconds = duration.split(":")
        durations_in_seconds = timedelta(hours = int(hours), minutes = int(minutes), seconds = int(seconds)).total_seconds()
        return durations_in_seconds
