import ast
from datetime import datetime
from pytz import timezone

from ingestion_framework.enums.DynamodbEnum import DynamodbEnum


class ColumnService:
    
    """
    def __init__(self,  spark, read_df, pipeline, logger):
        self.spark = spark
        self.app_name = pipeline.application.name
        self.read_df = read_df
        self.pipeline_id = pipeline.metadata.id
        self.pipeline=pipeline
        self.logger = logger
        self.pipeline_columns=pipeline.pipeline_columns

    def column_parser_runner(self):
        logger.info(f"pipeline id:{self.pipeline_id} - creating a temp view on csv read df")
        self.temp_view_name = self.pipeline_id.replace("-","_")
        self.read_df.createOrReplaceTempView(self.temp_view_name)

        # Building the dynamic sql and running it on temp view
        fl_df = self.spark.sql(self.cast_src_to_tgt_types())
        return fl_df

    def cast_src_to_tgt_types(self):
        sorted_cols_dicts_lst = ColumnService.sort_columns_by_sequence_number(self.pipeline_columns)
        query_string = ''
        sep = ','

        for sorted_cols_dict in sorted_cols_dicts_lst:
            if DynamodbEnum.TARGET_DATETIME_FORMAT in sorted_cols_dict and sorted_cols_dict.get(DynamodbEnum.TARGET_DATETIME_FORMAT) !=None and sorted_cols_dict.get(DynamodbEnum.TARGET_DATETIME_FORMAT) != "":
                query_string += str(f'cast(date_format({sorted_cols_dict[DynamodbEnum.SOURCE_COLUMN_NAME.value]},\'{sorted_cols_dict[DynamodbEnum.TARGET_DATETIME_FORMAT]}\') as {sorted_cols_dict[DynamodbEnum.TARGET_DATATYPE.value]})')
            elif DynamodbEnum.TARGET_LENGTH.value in sorted_cols_dict and sorted_cols_dict.get(DynamodbEnum.TARGET_LENGTH.value) !=None and sorted_cols_dict.get(DynamodbEnum.TARGET_LENGTH.value) !="":
                if DynamodbEnum.TARGET_PRECISION.value in sorted_cols_dict and sorted_cols_dict.get(DynamodbEnum.TARGET_PRECISION.value) !=None and sorted_cols_dict.get(DynamodbEnum.TARGET_PRECISION.value) !="":
                    query_string += str(f"cast({sorted_cols_dict[DynamodbEnum.SOURCE_COLUMN_NAME.value]} as {sorted_cols_dict[DynamodbEnum.TARGET_DATATYPE.value]}({sorted_cols_dict.get(DynamodbEnum.TARGET_LENGTH.value)}, {sorted_cols_dict.get(DynamodbEnum.TARGET_PRECISION.value)}))")
                elif sorted_cols_dict[DynamodbEnum.TARGET_DATATYPE.value].lower() == "char" or sorted_cols_dict[DynamodbEnum.TARGET_DATATYPE.value].lower() == "varchar":
                    query_string += str(f"cast({sorted_cols_dict[DynamodbEnum.SOURCE_COLUMN_NAME.value]} as {sorted_cols_dict[DynamodbEnum.TARGET_DATATYPE.value]}({sorted_cols_dict.get(DynamodbEnum.TARGET_LENGTH.value)}))")
                else:
                    query_string += str(f"cast({sorted_cols_dict[DynamodbEnum.SOURCE_COLUMN_NAME.value]} as {sorted_cols_dict[DynamodbEnum.TARGET_DATATYPE.value]})")
            else:
                query_string += str(f"cast({sorted_cols_dict[DynamodbEnum.SOURCE_COLUMN_NAME.value]} as {sorted_cols_dict[DynamodbEnum.TARGET_DATATYPE.value]})")
                                        
            query_string += str(f" as {sorted_cols_dict[DynamodbEnum.TARGET_COLUMN_NAME.value]}" + sep)

        log_chng_key = self.inv_dict[DynamodbEnum.LOG_CHNG_INDICATOR_KEY]
        if log_chng_key is not None and log_chng_key != '' and log_chng_key != 'null' and log_chng_key != []:
            log_chng_key = ast.literal_eval(self.inv_dict[DynamodbEnum.LOG_CHNG_INDICATOR_KEY])
        else:
            log_chng_key = []

        if len(log_chng_key) >= 1:
            logger.info(f'pipeline id:{self.pipeline_id} - LogIndicatorChangeKey - Available - {log_chng_key}')
            log_chang_key_column = log_chng_key[0]
            if log_chang_key_column not in sorted_cols_dicts_lst:
                query_string += str(f"{log_chang_key_column}" + sep)
                logger.info(f'pipeline id:{self.pipeline_id} - LogIndicatorChangeKey is added in the query')
        
        query_string = query_string[:-1]
        full_query = f"select {query_string} from {self.temp_view_name}"
        logger.info(f"pipeline id:{self.pipeline_id} - Dynamic sql is as follows: {full_query}")
        return full_query


    def get_column_list(self):
        sorted_cols_dicts_lst = ColumnService.sort_columns_by_sequence_number(self.pipeline_columns)
        src_cols_lst = []
        tgt_col_lst = []
        tgt_data_type = []
        tgt_col_len = []
        tgt_col_prec = []

        for nl in sorted_cols_dicts_lst:
            src_cols_lst.append(nl[DynamodbEnum.SOURCE_COLUMN_NAME.value])
            tgt_col_lst.append(nl[DynamodbEnum.TARGET_COLUMN_NAME.value])
            tgt_data_type.append(nl[DynamodbEnum.TARGET_DATATYPE.value])
            tgt_col_len.append(nl.get(DynamodbEnum.TARGET_LENGTH.value, 0))
            tgt_col_prec.append(nl.get(DynamodbEnum.TARGET_PRECISION.value, 0))

        cor_type_lst = []
        for index in range(len(tgt_data_type)):
            if tgt_data_type[index] == 'DATETIME' or tgt_data_type[index] == 'datetime':
                cor_type_lst.append('TIMESTAMP')
            elif tgt_data_type[index] == 'STRING' and int(tgt_col_len[index]) != 0:
                cor_type_lst.append('VARCHAR')
            else:
                cor_type_lst.append(tgt_data_type[index])
        
        column_structure = """"""

        for index in range(len(tgt_data_type)):
            if tgt_col_len[index] != 0 and tgt_col_prec[index] != 0:
                tmp = "`{}`   {}({},{}),\n".format(tgt_col_lst[index], cor_type_lst[index], tgt_col_len[index], tgt_col_prec[index])
            elif cor_type_lst[index].lower() == "decimal":
                if tgt_col_len[index] == 0:
                    tgt_col_len[index] = 38
                tmp = "`{}`   {}({},{}),\n".format(tgt_col_lst[index], cor_type_lst[index], tgt_col_len[index], tgt_col_prec[index])
            elif cor_type_lst[index].lower() == "char" or cor_type_lst[index].lower() == "varchar":
                tmp = "`{}`   {}({}),\n".format(tgt_col_lst[index], cor_type_lst[index], tgt_col_len[index])
            else:
                tmp = "`{}`   {},\n".format(tgt_col_lst[index], cor_type_lst[index])
            column_structure = column_structure + tmp

        column_list = column_structure[:-2]
        return column_list
    """
    
    @staticmethod
    def sort_columns_by_sequence_number(pipeline_columns):
        sorted_pipeline_columns = sorted(pipeline_columns, key=lambda column: int(column.sequence_number))
        return sorted_pipeline_columns



                                         
        



