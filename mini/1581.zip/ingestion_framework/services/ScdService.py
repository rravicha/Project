from datetime import datetime
from pyspark.sql.functions import lit



class ScdService:

    def __init__(self, spark, logger):
        self.spark = spark
        self.logger = logger


    def apply_scd(self, full_data, incremental_data, pipeline_metadata):
        pipeline_id = pipeline_metadata.id
        self.logger.info(f'{pipeline_id} - Started')
        
        if full_data:
            incremental_data_vw = f'{pipeline_id.replace("-","_")}_incremental_data_vw'
            incremental_data.createOrReplaceTempView(incremental_data_vw)

            full_data_vw = f'{pipeline_id.replace("-","_")}_full_data_vw'
            full_data.createOrReplaceTempView(full_data_vw)

            join_condition = self.get_join_condition(pipeline_id, pipeline_metadata.primary_key_list)
            
            if len(pipeline_metadata.change_indicator_key_list) >= 1:
                self.logger.info(f'{pipeline_id} - ChangeIndicatorKey - {pipeline_metadata.change_indicator_key_list}')
                return self.cdc_with_change_indicator(pipeline_id, pipeline_metadata.change_indicator_key_list, full_data_vw, incremental_data_vw, join_condition)
            
            else:
                self.logger.info(f'{pipeline_id} - ChangeIndicatorKey - Not Given')
                return self.cdc_without_change_indicator(pipeline_id, full_data_vw, incremental_data_vw, join_condition, full_data, incremental_data)

        self.logger.info(f'{pipeline_id} - Target table/partition does not exist')
        insert_data = incremental_data
        self.logger.info(f'{pipeline_id} - Insert Data - Ready. Count - {insert_data.count()}')
        return insert_data, None, None, None


    def cdc_with_change_indicator(self, pipeline_id, change_indicator_key_list, full_data_vw, incremental_data_vw, join_condition):
        change_indicator = change_indicator_key_list[0]
        
        supported_inserts = self.get_supported_cdc_inserts()
        insert_data = self.spark.sql(f"select incremental_data_vw.* from {incremental_data_vw} incremental_data_vw where incremental_data_vw.{change_indicator} in {supported_inserts}")
        insert_data = insert_data.drop(change_indicator)
        if 'rno' in insert_data.columns:
            insert_data = insert_data.drop('rno')
        self.logger.info(f'{pipeline_id} - Insert Data - Ready. Count - {insert_data.count()}')
        
        supported_updates = self.get_supported_cdc_updates()
        update_data = self.spark.sql(f"select incremental_data_vw.* From {incremental_data_vw} incremental_data_vw left join {full_data_vw} full_data_vw on {join_condition} where incremental_data_vw.{change_indicator} in {supported_updates}")
        update_data = update_data.drop(change_indicator)
        if 'rno' in update_data.columns:
            update_data = update_data.drop('rno')
        self.logger.info(f'{pipeline_id} - Update Data - Ready. Count - {update_data.count()}')
        
        supported_deletes = self.get_supported_cdc_deletes()
        delete_data = self.spark.sql(f"select incremental_data_vw.* from {incremental_data_vw} incremental_data_vw where incremental_data_vw.{change_indicator} in {supported_deletes}")
        delete_data = delete_data.drop(change_indicator)
        self.logger.info(f'{pipeline_id} - Delete Data - Ready. Count - {delete_data.count()}')
        
        unchanged_data = self.spark.sql(f"select full_data_vw.* From {full_data_vw} full_data_vw Left join {incremental_data_vw} incremental_data_vw on {join_condition} where incremental_data_vw.{change_indicator} is null")
        self.logger.info(f'{pipeline_id} - Unchanged Data - Ready. Count - {unchanged_data.count()}')
        
        return insert_data, update_data, delete_data, unchanged_data
    
    
    def cdc_without_change_indicator(self, pipeline_id, full_data_vw, incremental_data_vw, join_condition, full_data, incremental_data):
        #Primary key is given
        if join_condition != '':
            update_data = self.spark.sql(f"select incremental_data_vw.* From {incremental_data_vw} incremental_data_vw join {full_data_vw} full_data_vw on {join_condition}")
            self.logger.info(f'{pipeline_id} - Update Data - Ready. Count - {update_data.count()}')
            
            insert_data = incremental_data.subtract(update_data)
            self.logger.info(f'{pipeline_id} - Insert Data - Ready. Count - {insert_data.count()}')
            
            unchanged_data = full_data.subtract(update_data)
            self.logger.info(f'{pipeline_id} - Unchanged Data - Ready. Count - {unchanged_data.count()}')
            
            return insert_data ,update_data, None, unchanged_data
        #Primary Key is not given
        else:
            insert_data = incremental_data
            self.logger.info(f'{pipeline_id} - Insert Data - Ready. Count - {insert_data.count()}')
            return insert_df, None, None, None


    def get_supported_cdc_updates(self):
        supported_updates = ''
        
        for supported_update in ['UPD']:
            supported_updates += f"\"{supported_update}\","
        
        if supported_updates != '':
            supported_updates = "("+supported_updates[:-1]+")"
            
        return supported_updates
    
    
    def get_supported_cdc_inserts(self):
        supported_inserts = ''
        
        for supported_insert in ['INS']:
            supported_inserts += f"\"{supported_insert}\","
        
        if supported_inserts != '':
            supported_inserts = "("+supported_inserts[:-1]+")"
            
        return supported_inserts
    
    
    def get_supported_cdc_deletes(self):
        supported_deletes = ''
        
        for supported_delete in ['DEL']:
            supported_deletes += f"\"{supported_delete}\","
        
        if supported_deletes != '':
            supported_deletes = "("+supported_deletes[:-1]+")"
            
        return supported_deletes
    

    def get_join_condition(self, pipeline_id, primary_key_list):
        self.logger.info(f'{pipeline_id} - Started')
        
        join_condition = ''
        index = 0
        
        for col in primary_key_list:
            join_condition = join_condition + ' full_data_vw.' + col + ' = ' + 'incremental_data_vw.' + col + ' and'

        if join_condition != '':
            index = join_condition.rfind("and")
            join_condition = join_condition[:index]
        
        self.logger.info(f'{pipeline_id} - Succeeded')
        return join_condition


    #Need more work on this
    def cdc_type4(self,primary_key,full_target_df, insert_df):
        if full_target_df== None:
            final_df = insert_df.withColumn('etl_insert_ts', lit(datetime.now()))
            return final_df
        deltaTable = full_target_df.join(insert_df, on=primary_key, how='anti').union(insert_df)
        final_df = deltaTable.withColumn('etl_insert_ts', lit(datetime.now()))
        return final_df