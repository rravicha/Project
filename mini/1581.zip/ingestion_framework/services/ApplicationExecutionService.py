import concurrent.futures
from datetime import datetime,timedelta,date
from ingestion_framework.services.YamlService import YamlService
from ingestion_framework.handler.PipelineHandler import PipelineHandler
from ingestion_framework.services.JobStatusService import JobStatusService


class ApplicationExecutionService():

    @staticmethod
    def log_application_parameters(app_name,aws_region, run_all_pipelines_flag, pipeline_id, pipeline_version, job_env, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, run_in_sequence_flag, parallel_pipelines_limit, logger):
        logger.info('Input Parameters')

        logger.info(f'App Name : {app_name}')
        logger.info(f'Run All Pipelines flag : {run_all_pipelines_flag}')
        logger.info(f'Pipeline Id : {pipeline_id}')
        logger.info(f'Pipeline Version : {pipeline_version}')
        logger.info(f'Job Environment : {job_env}')
        logger.info(f'AWS Region : {aws_region}')
        logger.info(f'Business Start Date time : {business_start_datetime}')
        logger.info(f'Business End Date time : {business_end_datetime}')
        logger.info(f'Run in Daily chunks flag : {run_in_daily_chunks_flag}')
        logger.info(f'Run in Sequence flag : {run_in_sequence_flag}')
        logger.info(f'Number of pipelines to run in Parallel : {parallel_pipelines_limit}')


    @staticmethod
    def validate_application_parameters(app_name,aws_region, run_all_pipelines_flag, pipeline_id, pipeline_version, job_env, logger):
        print(f'level 4- app_name:{app_name}')
        if not app_name:
            logger.error(f'Application Name is needed | app_name:{app_name}')
            raise SystemExit(f'Application Name is needed | app_name:{app_name}')

        if run_all_pipelines_flag != "true" and not pipeline_id:
            logger.error('Pipeline id is needed when Run All Pipelines flag is false')
            raise SystemExit('Pipeline id is needed when Run All Pipelines flag is false')
        
        if run_all_pipelines_flag != "true" and pipeline_version:
            number_of_pipeline_ids = len(pipeline_id.split(","))
            number_of_pipeline_versions = len(pipeline_version.split(","))
            if number_of_pipeline_ids != number_of_pipeline_versions:
                logger.error(f'Number of Pipeline ids given : {number_of_pipeline_ids} is does not match with number of versions givnen: {number_of_pipeline_versions}')
                raise SystemExit(f'Number of Pipeline ids given : {number_of_pipeline_ids} is does not match with number of versions givnen: {number_of_pipeline_versions}')
        
        if not job_env:
            logger.error('Job Environment is needed')
            raise SystemExit('Job Environment is needed')


    @staticmethod
    def compute_pipelineids_with_versions(app_name, run_all_pipelines_flag, pipeline_id, pipeline_version, logger):
        pipelineids_with_versions = {}
        error_pipelineids = []
        calculated_pipelineids_with_versions = YamlService(logger).get_all_pipelineids_with_latest_versions(app_name)
    
        #Run all enabled block
        if run_all_pipelines_flag == "true":
            pipelineids_with_versions = calculated_pipelineids_with_versions  
        #Run all disabled block
        else:
            #Processing given pipeline ids with given pipeline versions
            if pipeline_version:
                pipeline_ids = pipeline_id.split(",")
                pipeline_versions = pipeline_version.split(",")

                for id, version in zip(pipeline_ids, pipeline_versions):

                    pipelineids_with_versions[id.strip()] = version.strip()
            #Processing given pipeline ids with calculated pipeline versions
            else:
                for id in pipeline_id.split(","):
                    if id.strip() in calculated_pipelineids_with_versions:
                        pipelineids_with_versions[id] = calculated_pipelineids_with_versions[id]
                    else:
                        error_pipelineids.append(id)

        if len(error_pipelineids) > 0:
            logger.error(f'The following pipeline ids were either not valid or not active : {error_pipelineids}')
            raise SystemExit(f'The following pipeline ids were either not valid or not active : {error_pipelineids}')
        elif len(pipelineids_with_versions) == 0:
            raise SystemExit('No pipelines found with valid pipeline_id, pipeline_version and active status.')
        else:
            logger.info('List of pipelines with versions identified:')
            for id, version in pipelineids_with_versions.items():
                logger.info(f'Pipeline Id:{id}  -> Version:{version}')

            return pipelineids_with_versions


    @staticmethod
    def trigger_pipelines_in_parallel(pipelineids_with_versions, app_name, job_env, aws_region, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, parallel_pipelines_limit, spark, logger):
    
        with concurrent.futures.ThreadPoolExecutor(max_workers=parallel_pipelines_limit) as pipeline_executor:
            pipeline_executors = []
            for pipeline_id, pipeline_version in pipelineids_with_versions.items():
                pipeline_executors.append(pipeline_executor.submit(
                    PipelineHandler.run_pipeline, app_name, pipeline_id, pipeline_version, job_env, aws_region, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, spark, logger)
                )
    
        pipeline_response_list = []
        for pipeline_executor in concurrent.futures.as_completed(pipeline_executors):
            pipeline_response_list.extend(pipeline_executor.result())
     
        return pipeline_response_list


    @staticmethod
    def trigger_pipelines_in_sequence(required_pipelines_with_versions, app_name, job_env, aws_region, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, spark, logger):
        pipeline_response_list = []
        for pipeline_id, pipeline_version in required_pipelines_with_versions.items():
            pipeline_response = PipelineHandler.run_pipeline(app_name, pipeline_id, pipeline_version, job_env, aws_region, business_start_datetime, business_end_datetime, run_in_daily_chunks_flag, spark, logger)

            pipeline_response_list.extend(pipeline_response)

        return pipeline_response_list


    @staticmethod
    def log_pipeline_response(pipeline_response_list, logger):

        logger.info('****************Execution Summary****************\n')
        for pipeline_response in pipeline_response_list:
            logger.info(f'Pipeline Id : {pipeline_response.id}')
            logger.info(f'Job Status : {pipeline_response.jobstatus}')
            logger.info(f'Error Message : {pipeline_response.error_message}')
            logger.info(f'Business Start Datetime : {pipeline_response.business_start_datetime}')
            logger.info(f'Business End Datetime : {pipeline_response.business_end_datetime}\n')

        logger.info('*************************************************')