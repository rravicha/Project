import boto3
from ingestion_framework.enums.JobParameters import JobParameters
from ingestion_framework.services.ColumnService import ColumnService


class AthenaRepository:
    def __init__(self, logger):
        self.logger = logger


    def create_athena_table_using_pipeline_columns(self, pipeline_id, app_name, domain_name, resource, file_location, job_env):
        self.logger.info(f"{pipeline_id} - Started")

        athena_us_east_1_client = boto3.client(JobParameters.ATHENA.value, region_name=JobParameters.US_EAST_1.value)
        athena_us_west_2_client  = boto3.client(JobParameters.ATHENA.value, region_name=JobParameters.US_WEST_2.value)
        athena_clients_list=[athena_us_east_1_client, athena_us_west_2_client]
        
        col_names, col_types, col_lengths, col_precisions = self.get_pipeline_column_details(resource.columns)
        
        bucket_name = resource.connections[job_env].bucket_name
        file_name = resource.metadata.file_name
        output_location = f"s3://{bucket_name}/logs/athena/{file_name}/"
        
        athena_db_name = f"datamesh_{domain_name}_raw_{job_env}"
        execution_context = {'Database': athena_db_name}
        
        work_group_name = f"datamesh-{app_name}-{job_env}"
        file_location = file_location.replace("s3a://", "s3://")
        partition_columns = resource.metadata.partition_columns
        
        athena_queries_list = self.generate_athena_queries_using_pipeline_columns(pipeline_id, file_name, col_names, col_types, col_lengths, col_precisions, partition_columns, file_location)
        
        self.run_athena_queries(pipeline_id, athena_queries_list, athena_clients_list, execution_context, work_group_name, output_location)
        self.logger.info(f"{pipeline_id} - Succeeded")
    
    
    def get_pipeline_column_details(self, pipeline_columns):
        sorted_pipeline_columns = ColumnService.sort_columns_by_sequence_number(pipeline_columns)
        
        col_names = []
        col_types = []
        col_lengths = []
        col_precisions = []

        for column in sorted_pipeline_columns:
            col_names.append(column.name)
            col_lengths.append(column.length)
            col_precisions.append(column.precision)
            
            if column.datatype.lower() == "datetime":
                col_types.append('TIMESTAMP')
            elif column.datatype.lower() == "string" and column.length != 0:
                col_types.append('VARCHAR')
            else:
                col_types.append(column.datatype)
            
        return col_names, col_types, col_lengths, col_precisions
    
    
    def generate_athena_queries_using_pipeline_columns(self, pipeline_id, table_name, col_names, col_types, col_lengths, col_precisions, partition_columns, file_location):
        drop_table_query = f"DROP TABLE IF EXISTS `{table_name}`;"
        self.logger.info(f'{pipeline_id} - Drop table query - {drop_table_query}') 

        create_table_query_1 = """create external table IF NOT EXISTS `{}` (""".format(table_name)
        create_table_query_2 = """"""

        for index in range(len(col_types)):
            if col_lengths[index] != "" and col_precisions[index] != "":
                column = "`{}`   {}({},{}),\n".format(col_names[index], col_types[index], col_lengths[index], col_precisions[index])
            elif col_types[index].lower() == "decimal":
                if col_lengths[index] == "":
                    col_lengths[index] = 38
                column = "`{}`   {}({},{}),\n".format(col_names[index], col_types[index], col_lengths[index], col_precisions[index])
            elif col_types[index].lower() == "char" or col_types[index].lower() == "varchar":
                column = "`{}`   {}({}),\n".format(col_names[index], col_types[index], col_lengths[index])
            else:
                column = "`{}`   {},\n".format(col_names[index], col_types[index])
            create_table_query_2 = create_table_query_2 + column

        create_table_query_2 = create_table_query_2[:-2]
        if partition_columns == []:
            create_table_query_3 = """) STORED AS PARQUET LOCATION '{}/'""".format(file_location)
        else:
            partition_columns_query = ""
            for partition_column in partition_columns:
                partition_columns_query = partition_columns_query + f"{partition_column} string,"
            partition_columns_query = partition_columns_query[:-1]
            
            create_table_query_3 = """) PARTITIONED BY ({}) STORED AS PARQUET LOCATION '{}/'
            """.format(partition_columns_query, file_location)

        create_table_query = create_table_query_1 + create_table_query_2 + create_table_query_3
        self.logger.info(f'{pipeline_id} - Create table query - {create_table_query}')
        
        return [drop_table_query,create_table_query]
    
    
    def run_athena_queries(self, pipeline_id, athena_queries_list, athena_clients_list, execution_context, work_group_name, output_location):
        for client in athena_clients_list:
            region_name=client.meta.region_name
            self.logger.info(f'{pipeline_id} - in aws region - {region_name} - Started')
            for query in athena_queries_list:
                self.logger.info(f'{pipeline_id} - Executing the query - {query} - Started')
                result = client.start_query_execution(
                    QueryString=query,
                    QueryExecutionContext=execution_context,
                    WorkGroup=work_group_name,
                    ResultConfiguration={'OutputLocation': output_location})
                exec_id = result['QueryExecutionId']
                
                while True:
                    status = client.get_query_execution(QueryExecutionId=exec_id)
                    state = status['QueryExecution']['Status']['State']
                    if state not in ["RUNNING", "QUEUED", "CANCELED"]:
                        break
                if state == "FAILED":
                    error_message = status['QueryExecution']['Status']['StateChangeReason']
                    self.logger.info(f'{pipeline_id} - Query execution failed with the error - {error_message}')
                    raise Exception(f'{pipeline_id} - Query execution failed with the error - {error_message}')
                else:
                    self.logger.info(f'{pipeline_id} - Executing the query - Succeeded')


    def create_athena_table_using_dataframe_columns(self, pipeline_id, app_name, domain_name, data, file_location, job_env):
        self.logger.info(f"{pipeline_id} - Started")

        athena_us_east_1_client = boto3.client(JobParameters.ATHENA.value, region_name=JobParameters.US_EAST_1.value)
        athena_us_west_2_client  = boto3.client(JobParameters.ATHENA.value, region_name=JobParameters.US_WEST_2.value)
        athena_clients_list=[athena_us_east_1_client, athena_us_west_2_client]
        
        athena_db_name = f"datamesh_{domain_name}_processed_{job_env}"
        execution_context = {'Database': athena_db_name}
        work_group_name = f"datamesh-{app_name}-{job_env}"
        
        dataframe_columns = data.dtypes
        bucket_name = file_location[6:].split('/')[0]
        
        if file_location.endswith('/'):
            file_location = file_location[:-1]
        file_name = file_location.split('/')[-1]
        output_location = f"s3://{bucket_name}/logs/athena/{file_name}/"
        
        file_location = file_location.replace("s3a://", "s3://")
        
        athena_queries_list = self.generate_athena_queries_using_dataframe_columns(pipeline_id, file_name, dataframe_columns, file_location)
        
        self.run_athena_queries(pipeline_id, athena_queries_list, athena_clients_list, execution_context, work_group_name, output_location)
        self.logger.info(f"{pipeline_id} - Succeeded")
        
    
    def generate_athena_queries_using_dataframe_columns(self, pipeline_id, table_name, dataframe_columns, file_location):
        drop_table_query = f"DROP TABLE IF EXISTS `{table_name}`"
        self.logger.info(f'{pipeline_id} - Drop table query - {drop_table_query}')
        
        create_table_query_1 = f"""CREATE EXTERNAL TABLE IF NOT EXISTS `{table_name}` ("""

        create_table_query_2 = """"""
        for dataframe_column in dataframe_columns:
            column = "`{}`   {},\n".format(dataframe_column[0], dataframe_column[1])
            create_table_query_2 = create_table_query_2 + column
        create_table_query_2 = create_table_query_2[:-2]

        create_table_query_3 = """) STORED AS PARQUET LOCATION '{}/'""".format(file_location)

        create_table_query = create_table_query_1 + create_table_query_2 + create_table_query_3
        self.logger.info(f'{pipeline_id} - Create table query - {create_table_query}')
        
        return [drop_table_query, create_table_query]
