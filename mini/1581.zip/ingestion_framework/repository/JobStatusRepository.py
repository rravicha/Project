import boto3, json
from datetime import datetime
from boto3.dynamodb.conditions import Key, Attr

from ingestion_framework.enums.JobParameters import JobParameters
from ingestion_framework.enums.DynamodbEnum import DynamodbEnum


class JobStatusRepository:
    def __init__(self, logger):
        self.logger = logger


    def put_jobstatus_entry(self,pipeline_id, jobstatus_entry, job_env, aws_region):
        self.logger.info(f"{pipeline_id} - Started")
        
        dynamodb = boto3.resource(DynamodbEnum.DYNAMO_DB.value, region_name=aws_region)
        jobstatus_table_name = DynamodbEnum.JOB_STATUS_TABLE.value.format(job_env)        
        jobstatus_table = dynamodb.Table(jobstatus_table_name)
        self.logger.info(f"{pipeline_id} - Created JobStatus table object")
        
        dynamodb_response = jobstatus_table.put_item(Item=jobstatus_entry)
        self.logger.info(f"{pipeline_id} - Succeeded")
    
    
    def update_jobstatus_entry(self, pipeline_id, updated_jobstatus_entry, job_env, aws_region):
        self.logger.info(f"{pipeline_id} - Started")
        
        dynamodb = boto3.resource(DynamodbEnum.DYNAMO_DB.value, region_name=aws_region)
        jobstatus_table_name = DynamodbEnum.JOB_STATUS_TABLE.value.format(job_env)        
        jobstatus_table = dynamodb.Table(jobstatus_table_name)
        self.logger.info(f"{pipeline_id} - Created JobStatus table object")
        
        dynamodb_response = jobstatus_table.update_item(
            Key={
                DynamodbEnum.PIPELINE_ID.value: pipeline_id,
                DynamodbEnum.EXECUTION_ID.value: updated_jobstatus_entry[DynamodbEnum.EXECUTION_ID.value]
            },
            UpdateExpression="set business_order_from_dttm=:business_start_datetime, \
                                business_order_to_dttm=:business_end_datetime, \
                                execution_end_dttm=:job_end_datetime, \
                                job_status=:jobstatus_flag, \
                                landing_count=:landing_count, \
                                final_count=:final_count, \
                                processed_count=:processed_count, \
                                sla_met=:sla_met, \
                                error_message=:error_message",
            ExpressionAttributeValues={
                ':business_start_datetime': updated_jobstatus_entry[DynamodbEnum.EXECUTION_END_DTTM.value],
                ':business_end_datetime': updated_jobstatus_entry[DynamodbEnum.BUSINESS_ORDER_TO_DTTM.value],
                ':job_end_datetime': updated_jobstatus_entry[DynamodbEnum.EXECUTION_END_DTTM.value],
                ':jobstatus_flag': updated_jobstatus_entry[DynamodbEnum.JOB_STATUS.value],
                ':landing_count': updated_jobstatus_entry[DynamodbEnum.LANDING_COUNT.value],
                ':final_count': updated_jobstatus_entry[DynamodbEnum.FINAL_COUNT.value],
                ':processed_count': updated_jobstatus_entry[DynamodbEnum.PROCESSED_COUNT.value],
                ':sla_met': updated_jobstatus_entry[DynamodbEnum.SLA_MET.value],
                ':error_message': updated_jobstatus_entry[DynamodbEnum.ERROR_MESSAGE.value]
            },
            ReturnValues="UPDATED_NEW"
        )
        self.logger.info(f"{pipeline_id} - Succeeded")
    
    
    def get_last_successul_business_start_datetime(self, spark, pipeline_id, job_env, aws_region):
        dynamodb = boto3.resource(DynamodbEnum.DYNAMO_DB.value, region_name=aws_region)
        jobstatus_table_name = DynamodbEnum.JOB_STATUS_TABLE.value.format(job_env)
        jobstatus_table = dynamodb.Table(jobstatus_table_name)

        jobstatus_table_scan = jobstatus_table.scan(
            ProjectionExpression='pipeline_id, job_status, business_order_from_dttm',
            FilterExpression=Attr(DynamodbEnum.PIPELINE_ID.value).eq(pipeline_id)
            )

        jobstatus_table_items = jobstatus_table_scan[DynamodbEnum.TABLE_ITEMS.value]
        while DynamodbEnum.LAST_EVALUATED_KEY.value in jobstatus_table_scan:
            jobstatus_table_scan = jobstatus_table.scan(
                ExclusiveStartKey=jobstatus_table_scan[DynamodbEnum.LAST_EVALUATED_KEY.value],
                ProjectionExpression='pipeline_id, job_status, business_order_from_dttm',
                FilterExpression=Attr(DynamodbEnum.PIPELINE_ID.value).eq(pipeline_id))
            jobstatus_table_items.extend(jobstatus_table_scan[DynamodbEnum.TABLE_ITEMS.value])

        EncoderMethod = lambda self, obj: str(obj)
        EncoderMap = {JobParameters.DEFAULT.value: EncoderMethod}
        Encoder = type(JobParameters.ENCODER.value, (json.JSONEncoder,), EncoderMap)

        jobstatus_table_items_json = json.dumps(jobstatus_table_items, cls=Encoder)
        jobstatus_table_items_df = spark.read.json(spark.sparkContext.parallelize([jobstatus_table_items_json]))
        
        if jobstatus_table_items_df.count() > 0:
            successful_run_df = jobstatus_table_items_df.filter("job_status = '{}'".format(JobParameters.SUCCESS_FLAG.value))
            last_successful_run_df = successful_run_df.orderBy(DynamodbEnum.EXECUTION_END_DTTM.value, ascending=[False]).limit(1)
            last_successful_run_df = last_successful_run_df.select(DynamodbEnum.EXECUTION_END_DTTM.value)
        
            last_successful_run_start_time = last_successful_run_df.collect()[0][0] if last_successful_run_df.count() > 0 else None
        else:
            last_successful_run_start_time = None

        return last_successful_run_start_time

    
    def get_jobstatus_entries_for_pipeline(self, pipeline_id, job_env, aws_region):
        self.logger.info(f"{pipeline_id} - Started")
        
        dynamodb = boto3.resource(DynamodbEnum.DYNAMO_DB.value, region_name=aws_region)
        jobstatus_table_name = DynamodbEnum.JOB_STATUS_TABLE.value.format(job_env)
        jobstatus_table = dynamodb.Table(jobstatus_table_name)
        self.logger.info(f"{pipeline_id} - Created JobStatus table object")
        
        response = jobstatus_table.scan(FilterExpression=Key(DynamodbEnum.PIPELINE_ID.value).eq(pipeline_id))
        response_items = response['Items']
        
        while DynamodbEnum.LAST_EVALUATED_KEY.value in response:
            response = jobstatus_table.scan(FilterExpression=Key(DynamodbEnum.PIPELINE_ID.value).eq(pipeline_id), ExclusiveStartKey=response[DynamodbEnum.LAST_EVALUATED_KEY.value])
            response_items.extend(response['Items'])
        
        self.logger.info(f"{pipeline_id} - Succeeded")
        return response_items
    