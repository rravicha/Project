from abc import ABC, abstractmethod

class Connector(ABC):
    @abstractmethod
    def open_connection(self):
        pass
    
    @abstractmethod
    def read_data(self):
        pass
    
    @abstractmethod
    def write_data(self, df, write_location):
        pass
    
    @abstractmethod
    def close_connection(self):
        pass
    
    @abstractmethod
    def read_full_data(self):
        pass