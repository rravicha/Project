# System Libraries
import traceback, boto3, base64, json
from datetime import datetime
from pytz import timezone

# User Libraries
from ingestion_framework.repository.connectors.Connector import Connector
from ingestion_framework.enums.JobParameters import JobParameters
from ingestion_framework.services.ColumnService import ColumnService
from ingestion_framework.services.JobStatusService import JobStatusService


SEC_MGR = 'secretsmanager'
SEC_STR = 'SecretString'
SEC_BIN = 'SecretBinary'
USER = 'user'
USERNAME = 'username'
PWD = 'password'
HOST = 'host'
PORT = 'port'
DBNAME = 'dbname'
REQUIRE = 'require'
URL = 'url'
DRIVER = 'driver'
FETCH_SIZE = 'fetch_size'
SSL ='ssl'
SSL_FACTORY_PROPERTY = 'sslfactory'
SSL_FACTORY_VALUE = 'org.postgresql.ssl.NonValidatingFactory'
JDBC = 'jdbc'
 
class DatabaseConnector(Connector):
    def __init__(self, pipeline_metadata, app_name, domain_name, resource, job_env, aws_region, business_start_datetime, business_end_datetime, spark, logger):
        self.pipeline_id = pipeline_metadata.id
        self.pipeline_metadata = pipeline_metadata
        self.resource = resource
        self.job_env = job_env
        self.aws_region = aws_region
        self.business_start_datetime = business_start_datetime
        self.business_end_datetime = business_end_datetime
        self.spark = spark
        self.logger = logger
        
        
    def open_connection(self):
        connection_info = self.resource.connections[self.job_env]
        secret_manager_key = connection_info.secret_manager_key_name

        aws_client = boto3.client(SEC_MGR)
        secret_manager_response = aws_client.get_secret_value(SecretId=secret_manager_key)
        
        if SEC_STR in secret_manager_response:
            secret_manager_value = json.loads(secret_manager_response[SEC_STR])
        else:
            secret_manager_value = json.loads(base64.b64decode(secret_manager_response[SEC_BIN]))
        
        return secret_manager_value
            

    def read_data(self):
        source_query, business_start_datetime, business_end_datetime = self.get_source_query()
        read_df = self.read_data_using_query(source_query)
        return read_df, business_start_datetime, business_end_datetime
    
    
    def get_source_query(self):
        current_timestamp = datetime.now(timezone('US/Eastern')).strftime("%Y-%m-%d %H:%M:%S")
        query = self.resource.metadata.query
        read_start_time = ""
        read_end_time = ""

        if query == '':
            table_name = self.resource.metadata.table_name
            filter = self.resource.metadata.filter
            if filter != '':
                filter = f" where {filter}"
            
            sorted_pipeline_columns = ColumnService.sort_columns_by_sequence_number(self.resource.columns)
            column_names = ""
            for pipeline_column in sorted_pipeline_columns:
                column_names += f"{pipeline_column.name}, "
            column_names = column_names[:-2]

            if self.pipeline_metadata.load_type == "delta":
                delta_filter = ""
                if self.pipeline_metadata.cdc_timestamp_key_list != []:
                    cdc_keys = self.pipeline_metadata.cdc_timestamp_key_list
                    if not self.business_start_datetime:
                        read_start_time = JobStatusService(self.logger).get_last_successul_business_start_datetime(self.spark, self.pipeline_id, self.job_env, self.aws_region)
                        if not read_start_time:
                            read_start_time = datetime(1900, 1, 1, 00, 00, 00, 00)
                    else:
                        read_start_time = self.business_start_datetime
                
                    read_end_time = current_timestamp if not self.business_end_datetime else self.business_end_datetime
                
                    for cdc_key in cdc_keys :
                        if self.resource.metadata.database_type == 'oracle':
                            delta_filter += f"{cdc_key} at time zone 'America/New_York' between to_timestamp('{read_start_time}','yyyy-MM-dd hh24:mi:ss') \
                                    and to_timestamp('{read_end_time}','yyyy-MM-dd hh24:mi:ss') or "
                        elif self.resource.metadata.database_type == 'postgres':
                            delta_filter += f"{cdc_key} between at time zone 'America/New_York' '{read_start_time}' and '{read_end_time}' or "
                        else:
                            delta_filter += f"{cdc_key} between '{read_start_time}' and '{read_end_time}' or "
                    delta_filter = delta_filter[:-4]
                    
                    if filter != "":
                        filter = f" where ({filter}) and ({delta_filter})"
                    else:
                        filter = f" where {delta_filter}"            

            query = f"select {column_names} from {table_name} {filter}"
        elif '{}' in query:
            if not self.business_start_datetime:
                read_start_time = JobStatusService(self.logger).get_last_successul_business_start_datetime(self.spark, self.pipeline_id, self.job_env, self.aws_region)
            else:
                read_start_time = self.business_start_datetime
                
            read_end_time = current_timestamp if not self.business_end_datetime else self.business_end_datetime
            
            if not read_start_time:
                read_start_time = current_timestamp

                table_name = self.resource.metadata.table_name
                sorted_pipeline_columns = ColumnService.sort_columns_by_sequence_number(self.resource.columns)
                column_names = ""
                for pipeline_column in sorted_pipeline_columns:
                    column_names += f"{pipeline_column.name}, "
                column_names = column_names[:-2]

                query = f"select {column_names} from {table_name}"
            else:
                query = query.format(read_start_time, read_end_time)
        
        self.logger.info(f'{self.pipeline_id} - Updated Query - {query}')
            
        return query, read_start_time, read_end_time


    def read_data_using_query(self, source_query):
        secret_manager_value = self.open_connection()
        
        database_type = self.resource.metadata.database_type
        
        if database_type == "postgres" or database_type == "sybase" or database_type == "sqlserver":
            spark_options = self.prepare_spark_options(secret_manager_value, database_type)
            spark_options['query'] = source_query
        elif database_type == "db2" or database_type == "oracle":
            spark_options = self.prepare_spark_options(secret_manager_value, database_type)
            spark_options['dbtable'] = '(' + source_query + ') t'
        else:
            self.logger.error(f'{self.pipeline_id} - Failed with error: Database {database_type} is not supported')
            raise Exception(f'{self.pipeline_id} - Failed with error: Database {database_type} is not supported')
        
        spark_options[JobParameters.FETCH_SIZE] = '200000'
        
        self.logger.info(f"{self.pipeline_id} - Reading data - Started")
        try:
            read_df = self.spark.read.options(**spark_options).format(JDBC).load()
            self.logger.info(f"{self.pipeline_id} - Reading data - Succeeded - Count - {read_df.count()}")
            return read_df
        except Exception as err:
            self.logger.info(f'{self.pipeline_id} - Failed with error: {err}')
            traceback.print_exc()
            raise Exception(f'{self.pipeline_id} - Failed with error: {err}')
        finally:
            self.close_connection()


    def prepare_spark_options(self, secret_manager_value, database_type):
        spark_options = {
            USER: secret_manager_value[USERNAME],
            PWD: secret_manager_value[PWD]
        }
        
        host = secret_manager_value[HOST]
        port = secret_manager_value[PORT]
        db_name = secret_manager_value[DBNAME]

        if database_type == "postgres":
            spark_options[URL] = f"""jdbc:postgresql://{host}:{port}/{db_name}"""
            spark_options[DRIVER] = 'org.postgresql.Driver'
        elif database_type == "db2":
            spark_options[URL] = f"""jdbc:db2://{host}:{port}/{db_name}"""
            spark_options[DRIVER] = 'com.ibm.db2.jcc.DB2Driver'
        elif database_type == "oracle":
            spark_options[URL] = f"""jdbc:oracle:thin:@{host}:{port}:{db_name}"""
            spark_options[DRIVER] = 'oracle.jdbc.driver.OracleDriver'
        elif database_type == "sqlserver":
            spark_options[URL] = f"""jdbc:sqlserver://{host}:{port};databaseName={db_name}"""
            spark_options[DRIVER] = 'com.microsoft.sqlserver.jdbc.SQLServerDriver'
        elif database_type == "sybase":
            spark_options[URL] = f"""jdbc:sybase:Tds:{host}:{port}/{db_name}?"""
            spark_options[DRIVER] = 'com.mysql.jdbc.Driver'

        if ".rds.amazonaws.com" in host:
            spark_options[SSL] = 'true'
            spark_options[SSL_FACTORY_PROPERTY] = SSL_FACTORY_VALUE

        return spark_options


    def write_data(self, write_df):
        secret_manager_value = self.open_connection()
        
        database_type = self.resource.metadata.database_type

        if database_type == "postgres":
            spark_options = self.prepare_spark_options(secret_manager_value, database_type)
        else:
            self.logger.error(f'{self.pipeline_id} - Failed with error: Database {database_type} is not supported')
            raise Exception(f'{self.pipeline_id} - Failed with error: Database {database_type} is not supported')
        
        table_name = self.resource.metadata.table_name
        jdbc_url = spark_options[URL]
        del spark_options[URL]

        self.logger.info(f"{self.pipeline_id} - Writing data - Started")
        try:
            write_df.write.jdbc(url=jdbc_url, mode=JobParameters.OVERWRITE_MODE.value, table=table_name, properties=spark_options)
        except Exception as err:
            self.logger.error(f'{self.pipeline_id} - Writing data - Failed with error: {err}')
            traceback.print_exc()
            raise Exception(f'{self.pipeline_id} - Writing data - Failed with error: {err}')
        else:
            self.logger.info(f"{self.pipeline_id} - Writing data - Succeeded")
        finally:
            self.close_connection()


    def read_full_data(self):        
        sorted_pipeline_columns = ColumnService.sort_columns_by_sequence_number(self.resource.columns)
        column_names = ""
        for pipeline_column in sorted_pipeline_columns:
            column_names += f"{pipeline_column.name}, "
        column_names = column_names[:-2]
        
        table_name = self.resource.metadata.table_name
        source_query = f"select {column_names} from {table_name}"
        
        read_df = self.read_data_using_query(source_query)
        return read_df
    
    
    def close_connection(self):
        pass
