# System Libraries
import ast, boto3, csv
from datetime import datetime
from xml.etree import ElementTree as ET

# User Libraries
from ingestion_framework.repository.connectors.Connector import Connector
from ingestion_framework.enums.JobParameters import JobParameters
from ingestion_framework.services.ColumnService import ColumnService
from ingestion_framework.services.ScdService import ScdService
from ingestion_framework.repository.AthenaRepository import AthenaRepository

DEFAULT_TARGET_NUM_PARTITIONS = 1
PARQUET = 'parquet'

class FileConnector(Connector):

    def __init__(self, pipeline_metadata, app_name, domain_name, resource, job_env, aws_region, business_start_datetime, business_end_datetime, spark, logger):
        self.spark = spark
        self.logger = logger
        self.pipeline_metadata = pipeline_metadata
        self.app_name = app_name
        self.domain_name = domain_name
        self.resource = resource
        self.job_env = job_env
        self.aws_region = aws_region
        self.business_start_datetime = business_start_datetime
        self.business_end_datetime = business_end_datetime
        
        self.pipeline_id = self.pipeline_metadata.id


    def open_connection(self):
        pass


    def read_data(self):
        self.logger.info(f"{self.pipeline_id} - Started")
        
        file_server_type = self.resource.metadata.file_server_type
        self.logger.info(f"{self.pipeline_id} - File Server : {file_server_type}")
        
        if file_server_type == "s3":
            data = self.read_s3_file()
            self.logger.info(f"{self.pipeline_id} - Succeeded - Count - {data.count()}")
        else:
            self.logger.info(f"{self.pipeline_id} - The file server : {file_server_type} is not supported")
            raise Exception(f"{self.pipeline_id} - The file server : {file_server_type} is not supported")
        
        return data, self.business_start_datetime, self.business_end_datetime
    
    
    def read_s3_file(self):
        connection = self.resource.connections[self.job_env]
        bucket_name = self.clean_path_string(connection.bucket_name)
                
        file_path = self.clean_path_string(self.resource.metadata.file_path)
        file_name = self.clean_path_string(self.resource.metadata.file_name)
            
        file_format = self.clean_path_string(self.resource.metadata.file_format_metadata.file_format)
        
        if file_format == "parquet":
            data = self.read_parquet_data(bucket_name, file_path, file_name)
        elif file_format == "xml":
            data = self.read_xml_data(bucket_name, file_path, file_name)
        elif file_format == "excel":
            data = self.read_excel_data(bucket_name, file_path, file_name)
        elif file_format == "csv" or file_format == "pip":
            data = self.read_csv_data(bucket_name, file_path, file_name)
        else:
            raise Exception("The file format :{file_format} is not supported")

        return data


    def clean_path_string(self, path_string):
        path_string = path_string.strip()
        path_string = path_string[1:] if path_string.startswith("/") else path_string
        path_string = path_string[:-1] if path_string.endswith("/") else path_string
        
        return path_string
    
    
    def read_parquet_data(self, bucket_name, file_path, file_name):
        parquet_file_location = f"s3://{bucket_name}/{file_path}/{file_name}"
        
        if self.resource.metadata.partition_columns != []:
            if self.business_end_datetime != "":
                partition_value = self.business_end_datetime.split(' ')[0]
            else:
                partition_value = datetime.now().strftime('%Y-%m-%d')
            parquet_file_location = parquet_file_location + f"/{partition_columns[0]}={partition_value}"    
        
        data = self.spark.read.format('parquet').load(parquet_file_location)
        return data
    
    
    def read_xml_data(self, bucket_name, file_path, file_name):
        xml_file_location = f"s3://{bucket_name}/{file_path}/{file_name}"
        
        root_tag = self.resource.metadata.file_format_metadata.root_tag.strip()
        row_tag = self.resource.metadata.file_format_metadata.row_tag.strip()
        
        if root_tag == "" or row_tag == "":
            xml_file = self.get_s3_file(bucket_name, file_path, file_name)
            xml_tree = self.get_xml_tree_from_xml_file(xml_file)
            root_tag = self.extract_root_tag_from_xml_tree(xml_tree) if root_tag == "" else root_tag
            row_tag = self.extract_row_tag_from_xml_tree(xml_tree) if row_tag == "" else row_tag
        
        data = self.spark.read.format('com.databricks.spark.xml')   \
                .option('rootTag', root_tag)   \
                .option('row_tag',row_tag)  \
                .load(xml_file_location)
        
        return data
    

    def get_s3_file(self, bucket_name, file_path, file_name):
        s3_client = boto3.client(JobParameters.S3.value)
        file = s3_client.get_object(Bucket=bucket_name, Key=f"{file_path}/{file_name}")

        return file

    
    def get_xml_tree_from_xml_file(self, xml_file):
        file_content = xml_file['Body'].read()
        xml_tree = ET.ElementTree(ET.fromstring(file_content))

        return xml_tree

    
    def extract_root_tag_from_xml_tree(self, xml_tree):
        root = xml_tree.getroot()
        
        return root.tag


    def extract_row_tag_from_xml_tree(self, xml_tree):
        root = xml_tree.getroot()

        row_tag = ""
        for child in root:
            if row_tag == "":
                row_tag = child.tag
            elif row_tag != child.tag:
                self.logger.info(f"{self.pipeline_id} - XML file contains multiple row tags")
                raise Exception(f"{self.pipeline_id} - XML file contains multiple row tags")
        
        return row_tag
    
    
    def read_excel_data(self, bucket_name, file_path, file_name):
        excel_file_location = f"s3://{bucket_name}/{file_path}/{file_name}"
        sheet_name = self.resource.metadata.file_format_metadata.sheet_name.strip()
        
        data = self.spark.read.format("com.crealytics.spark.excel")\
                .option("useHeader" , "true")\
                .option("inferschema" , "true")\
                .option("dataAddress" , sheet_name+'!A1')\
                .load(excel_file_location)

        return data
    
    
    def read_csv_data(self, bucket_name, file_path, file_name):
        csv_file_location = f"s3://{bucket_name}/{file_path}/{file_name}"
        
        extracted_has_header, extracted_column_delimiter = self.extract_file_header_and_delimiter(bucket_name, file_path, file_name)
        has_header = self.resource.metadata.file_format_metadata.has_header
        has_header = has_header if has_header != "" else extracted_has_header
        
        row_delimiter = self.resource.metadata.file_format_metadata.row_delimiter
        row_delimiter = row_delimiter if row_delimiter!= "" else "\n"
        
        column_delimiter = self.resource.metadata.file_format_metadata.column_delimiter
        column_delimiter = column_delimiter if column_delimiter != "" else extracted_column_delimiter
        
        quote_character = self.resource.metadata.file_format_metadata.quote_character
        quote_character = quote_character if quote_character != "" else '"'
        
        escape_character = self.resource.metadata.file_format_metadata.escape_character
        escape_character = escape_character if escape_character != "" else '\\'
        
        data = self.spark.read.csv(csv_file_location, 
                                 #lineSep = row_delimiter,
                                 sep = column_delimiter,
                                 header = has_header,
                                 quote = quote_character,
                                 escape = escape_character,
                                 inferSchema = "true")
        
        if has_header == "false":
            sorted_pipeline_columns = ColumnService().sort_columns_by_sequence_number(self.resource.columns)
            column_names = []
            for pipeline_column in sorted_pipeline_columns:
                column_names.append(pipeline_column.name)
            return data.toDF(*column_names)
        else:
            return data

    
    def extract_file_header_and_delimiter(self, bucket_name, file_path, file_name):
        s3_client = boto3.client(JobParameters.S3.value)
        
        if "*" in file_name:
            files_list = s3_client.list_objects_v2(Bucket = bucket_name, Prefix = file_path)
            file = s3_client.get_object(Bucket = bucket_name, Key = files_list['Contents'][1]["Key"])
            sample_data = file['Body'].read().decode('utf-8')
        else:
            file = s3_client.get_object(Bucket = bucket_name, Key = f"{file_path}/{file_name}")
            sample_data = file['Body'].read(1024).decode('utf-8')
        
        has_header = csv.Sniffer().has_header(sample_data)
        
        dialect = csv.Sniffer().sniff(sample_data)
        column_delimiter = dialect.delimiter
        
        return has_header, column_delimiter
    

    def write_data(self, current_data):
        self.logger.info(f"{self.pipeline_id} - Started")
        
        file_server_type = self.resource.metadata.file_server_type
        
        if file_server_type == "s3":
            data = self.write_s3_file(current_data)
            self.logger.info(f"{self.pipeline_id} - Succeeded - Count - {data.count()}")
        else:
            self.logger.info(f"{self.pipeline_id} - The file server : {file_server_type} is not supported")
            raise Exception(f"{self.pipeline_id} - The file server : {file_server_type} is not supported")
        
        return data


    def write_s3_file(self, current_data):
        connection = self.resource.connections[self.job_env]
        bucket_name = self.clean_path_string(connection.bucket_name)
                
        file_path = self.clean_path_string(self.resource.metadata.file_path)
        file_name = self.clean_path_string(self.resource.metadata.file_name)    
        file_format = self.clean_path_string(self.resource.metadata.file_format_metadata.file_format)
        
        if file_format == "parquet":
            write_df = self.write_parquet_data(current_data, bucket_name, file_path, file_name)
        else:
            raise Exception("The file format :{file_format} is not supported")

        return write_df
    
    
    def write_parquet_data(self, current_data, bucket_name, file_path, file_name):
        self.write_parquet_data_to_landing(current_data, bucket_name, file_path, file_name)

        if self.pipeline_metadata.load_type == "delta" and self.does_s3_file_exist(bucket_name, f"{file_path}/{file_name}"):
            full_data, start_datetime, end_datetime = self.read_data()
            insert_data, update_data, delete_data, unchanged_data = ScdService(self.spark, self.logger).apply_scd(full_data, current_data, self.pipeline_metadata)
            data = self.compute_raw_data(insert_data, update_data, delete_data, unchanged_data)
        else:
            data = current_data
        
        final_data = self.write_parquet_data_to_raw(data, bucket_name, file_path, file_name)

        target_path = f"s3a://{bucket_name}/{file_path}/{file_name}"
        AthenaRepository(self.logger).create_athena_table_using_pipeline_columns(self.pipeline_metadata.id, self.app_name, self.domain_name, self.resource, target_path, self.job_env)

        return final_data
        
    
    def write_parquet_data_to_landing(self, current_data, bucket_name, file_path, file_name):
        file_path = f"data/landing"
        
        target_path = f"s3a://{bucket_name}/{file_path}/{file_name}"
        
        current_data.coalesce(DEFAULT_TARGET_NUM_PARTITIONS).write.format(PARQUET).mode(JobParameters.OVERWRITE_MODE.value).save(target_path)
                    
    
    def write_parquet_data_to_raw(self, data, bucket_name, file_path, file_name):
        temp_file_path = f"{file_path}/tmp"        
        temp_target_path = f"s3a://{bucket_name}/{temp_file_path}/{file_name}"
        data.coalesce(DEFAULT_TARGET_NUM_PARTITIONS).write.format(PARQUET).mode(JobParameters.OVERWRITE_MODE.value).save(temp_target_path)
        
        final_data = self.spark.read.format(PARQUET).load(temp_target_path)
        write_mode = JobParameters.OVERWRITE_MODE.value
        
        if self.resource.metadata.partition_columns != []:
            if self.business_end_datetime != "":
                partition_value = self.business_end_datetime.split(' ')[0]
            else:
                partition_value = datetime.now().strftime('%Y-%m-%d')
            file_name = f"{file_name}/{partition_columns[0]}={partition_value}"
            
            if self.does_s3_file_exist(bucket_name, f"{file_path}/{file_name}"):
                write_mode = 'append'
        
        target_path = f"s3a://{bucket_name}/{file_path}/{file_name}"

        final_data.coalesce(DEFAULT_TARGET_NUM_PARTITIONS).write.format(PARQUET).mode(write_mode).save(target_path)
        
        return final_data
    

    def compute_raw_data(self, insert_data, update_data, delete_data, unchanged_data):
        #Delete data is not part of unchanged data. So combining insert, update, unchanged is the result since we overwrite the file
        insert_update_data = insert_data.unionByName(update_data)
        return insert_update_data.unionByName(unchanged_data)

    
    def does_s3_file_exist(self, bucket_name, file_path):
        s3_client = boto3.client(JobParameters.S3.value)
        result = s3_client.list_objects(Bucket=bucket_name, Prefix=file_path)
        return 'Contents' in result
    
    
    def read_full_data(self):
        pass


    def close_connection(self):
        pass