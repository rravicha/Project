import traceback, boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

from ingestion_framework.enums.DynamodbEnum import DynamodbEnum


class DynamoDbRepository:
    @staticmethod
    def bulk_delete_by_sort_key(self, table_name, sort_key, partition_key, sk_values, aws_region, logger):
        try:
            dynamodb = boto3.resource(DynamodbEnum.DYNAMO_DB.value, region_name=aws_region)
            ddb_table = dynamodb.Table(table_name)
            sk_values_list = sk_values.split(',')
            for sk_id in sk_values_list:
                try:
                    ddb_table_scan = ddb_table.scan(FilterExpression=Key(sort_key).eq(sk_id))
                except ClientError as err:
                    logger.error(f"Exception Occured -  Error : {err} ")
                    raise
                else:
                    ddb_table_items = ddb_table_scan[DynamodbEnum.TABLE_ITEMS.value]

                while DynamodbEnum.LAST_EVALUATED_KEY.value in ddb_table_scan:
                    try:
                        ddb_table_scan = ddb_table.scan(FilterExpression=Key(sort_key).eq(
                            sk_id), ExclusiveStartKey=ddb_table_scan[DynamodbEnum.LAST_EVALUATED_KEY.value])
                    except ClientError as err:
                        logger.error(f"Exception Occured -  Error : {err} ")
                        raise
                    else:
                        ddb_table_items.extend(ddb_table_scan[DynamodbEnum.TABLE_ITEMS.value])

                try:
                    for item in ddb_table_items:
                        response = ddb_table.delete_item(Key={sort_key: item[sort_key], partition_key: item[partition_key]})
                        status_code = response[DynamodbEnum.RESPONSE_METADATA.value][DynamodbEnum.HTTP_STATUS_CODE.value]
                        if status_code != 200:
                            raise ValueError(f'Failed Item deletion - {sort_key},{partition_key} : {item[sort_key]}, {item[partition_key]}')
                except ValueError as error:
                    pass
        except Exception as err:
            traceback.print_exc()
            raise Exception(f'Failed with error: {err}')    